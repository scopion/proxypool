package articleDegree.master.service

import scala.concurrent.Future
import scala.concurrent.duration._
import scala.util.{Failure, Success, Try}

import akka.actor.{Actor, ActorLogging, _}
import akka.pattern._
import akka.util.Timeout
import articleDegree.master.MasterRedisMap._
import articleDegree.master.SlaveInfo
import org.slf4j.LoggerFactory
import utils.Awaits.aw
import articleDegree.master.executionContext

/**
  * Created by yujieshui on 2016/4/18.
  */
object SlaveInfoActor {

  case class All()

  case class Alive()

  case class Refresh(slaveInfo: SlaveInfo)

  type SlaveInfoMap = Map[String, SlaveInfo]

  class Service(val actor: ActorRef) {
    implicit val timeOut = Timeout(2.second)

    def all(): Future[SlaveInfoMap] = (actor ? All()).mapTo[SlaveInfoMap]

    def alive(): Future[SlaveInfoMap] = (actor ? Alive()).mapTo[SlaveInfoMap]

    def refresh(slaveInfo: SlaveInfo): Future[Boolean] = (actor ? Refresh(slaveInfo)).mapTo[Boolean]
  }

  def mkService(actorRef: ActorRef): Service = new Service(actorRef: ActorRef)


}

class SlaveInfoActor extends Actor with ActorLogging {

  import SlaveInfoActor._

  private[this] case class DoRefreshCacheSlaveInfoMap()

  private[this] case class DoCleanSlaveInfo()

  //获取reidis 中所有的slave info map 信息
  private[this] def getRedisSlaveInfoMap() =
    slaveInfoMap.toMap.await.mapValues(s => Try(SlaveInfo.formSerString(s))).filter(_._2.isSuccess).mapValues(_.get)

  private[this] var cacheSlaveInfoMap: Map[String, SlaveInfo] = getRedisSlaveInfoMap()

  private[this] val logger              = LoggerFactory.getLogger("slaveInfo")
  private[this] val refreshLog          = LoggerFactory.getLogger("refresh")
  private[this] val cleanLog            = LoggerFactory.getLogger("clean")
  private[this] val refreshCacheTimer   = context.system.scheduler.schedule(0.second, 1.second) {
    self ! DoRefreshCacheSlaveInfoMap()
  }
  private[this] val cleanSlaveInfoTimer = context.system.scheduler.schedule(5.second, 5.second) {
    self ! DoCleanSlaveInfo()
  }

  @throws[Exception](classOf[Exception])
  override def postStop(): Unit = {
    refreshCacheTimer.cancel()
    cleanSlaveInfoTimer.cancel()
  }

  override def receive: Actor.Receive = {
    case All()                        =>
      sender() ! cacheSlaveInfoMap
    case Alive()                      =>
      sender() ! cacheSlaveInfoMap.filter {
        case (slaveName, slaveInfo) =>
          System.currentTimeMillis() - slaveInfo.pingTime < 5.second.toMillis
      }
    case DoRefreshCacheSlaveInfoMap() =>
      refreshLog.debug("refresh cache ")
      cacheSlaveInfoMap = getRedisSlaveInfoMap()
    case DoCleanSlaveInfo()           =>
      val needCleanSlaveNames = cacheSlaveInfoMap.filter {
        case (slaveName, slaveInfo) =>
          System.currentTimeMillis() - slaveInfo.pingTime > 600.second.toMillis
      }.keys
      needCleanSlaveNames.map(slaveInfoMap.remove).foreach(_.onComplete {
        case Success(x) =>
          cleanLog.warn(s"clean slave ${x}")
        case Failure(x) =>
          cleanLog.error("clean failure ", x)
      })
    case Refresh(slaveInfo)           =>
      refreshLog.info(s"refresh slave success name:${slaveInfo.slaveName} ip:${slaveInfo.ip}")
      slaveInfoMap.insert(slaveInfo.slaveName, SlaveInfo.toSerString(slaveInfo)).await
      sender() ! true
  }
}
