package articleDegree.master

import scala.concurrent.duration._

import akka.actor._
import akka.pattern._
import akka.util.Timeout
import articleDegree._
import articleDegree.master.service._
import com.typesafe.config.Config


// todo add log to kafka
class MasterActor(config: Config) extends Actor with ActorLogging {

  private[this] val masterInfo = MasterInfo(
    name = utils.Utils.get_eth1_ip().getOrElse(utils.Utils.mac()),
    version = config.getString("master_version")
  )

  private[this] val cacheSlaveInfoService =
    SlaveInfoActor.mkService(context.actorOf(Props(new SlaveInfoActor)))

  private[this] val registeredService =
    RegisteredActor.mkService(context.actorOf(Props(new RegisteredActor(cacheSlaveInfoService, masterInfo))))

  private[this] val blackListService =
    BlackListActor.mkService(context.actorOf(Props(new BlackListActor(cacheSlaveInfoService))))

  private[this] val useProxyService =
    UseProxyActor.mkService(context.actorOf(Props(new UseProxyActor(cacheSlaveInfoService, blackListService))))

  implicit val timeOut = Timeout(10.second)

  override def receive: Receive = {
    case x: RequestProxyEntity =>
      useProxyService proxy x pipeTo sender()
    case rs: RegisteredSlave   =>
      registeredService register rs pipeTo sender()
    case x: UseProxy           =>
      useProxyService proxy x pipeTo sender()
    case x: GetSlaveInfo       =>
      useProxyService getSlaves x pipeTo sender()
    case x: SearchIp           =>
      useProxyService findByIp x pipeTo sender()
  }


}
