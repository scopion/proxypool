package articleDegree.master

import articleDegree._
import com.typesafe.config.ConfigFactory
import database.redis.RedisMap

/**
  * Created by yujieshui on 2016/4/1.
  */
object MasterRedisMap {
  val redisConfig = ConfigFactory.load().getConfig("redis")
  private val conf = ConfigFactory.load().getConfig("master_redis_map_name")

  val slaveInfoMap = RedisMap[String, String](redisConfig, conf.getString("slaveInfo".trim))
//  val waitRestartSlaveMap = RedisMap[String, String](redisConfig, conf.getString("waitRestartSlaveMap".trim))


}
