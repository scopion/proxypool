package articleDegree.master

/**
  * Created by yujieshui on 2016/4/1.
  */

import scala.concurrent.duration._
import scala.concurrent.{Await, Future}
import scala.io.Source

import java.io.{File, FileOutputStream, PrintWriter}

import akka.actor._
import akka.http.scaladsl.model._
import akka.http.scaladsl.server.RouteResult
import articleDegree.master.controller.ProxyPoolController
import com.typesafe.config.{ConfigFactory, ConfigValueFactory}
import sun.misc.{Signal, SignalHandler}
import utils.Utils
import utils.Utils._

object Main {

  def mkPidFile() = {
    val pw = new PrintWriter(new FileOutputStream(new File("/data/proxy-pool/pid")))
    pw.append(Utils.pid())
    pw.close()

  }

  def main(args: Array[String]) {

    // set system property  config file
    val configFile = args.toList.map(pattenConfigResource).find(_.nonEmpty).flatten.getOrElse(
      "application.conf"
    )
    System.setProperty("config.resource", configFile)

    val masterIp = Source.fromFile(new File("/data/proxy-pool/default_ip")).getLines().toSeq.head

    val masterConfig = ConfigFactory.load()
      .getConfig("articleDegree.master")
      .withValue("akka.remote.netty.tcp.hostname", ConfigValueFactory.fromAnyRef(masterIp))

    implicit val actorSystem: ActorSystem = ActorSystem("articleDegreeMaster", masterConfig)
    val masterActor = actorSystem.actorOf(Props(new MasterActor(masterConfig)), "masterActor")

    type Receive = PartialFunction[HttpRequest, Future[RouteResult]]

    mkPidFile()

    val proxyPool = new ProxyPoolController(actorSystem, masterActor, masterIp)
    // receive kill SIGTERM
    val sig = new Signal("TERM")
    Signal.handle(sig, new SignalHandler {
      override def handle(signal: Signal): Unit = {
        actorSystem.stop(masterActor)
        actorSystem.terminate()
        Await.result(actorSystem.whenTerminated, Duration.Inf)
        proxyPool.binding.map(_.unbind())
        System.exit(0)
      }
    })

  }
}
