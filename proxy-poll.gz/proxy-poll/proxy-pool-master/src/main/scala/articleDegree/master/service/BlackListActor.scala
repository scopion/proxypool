package articleDegree.master.service

import scala.concurrent.Future
import scala.concurrent.duration._
import scala.util.{Failure, Success, Try}

import akka.actor._
import akka.pattern._
import akka.util.Timeout
import articleDegree.UserEnum
import articleDegree.master.SlaveInfo
import org.slf4j.LoggerFactory

/**
  * Created by yujieshui on 2016/4/18.
  */
object BlackListActor {

  case class GlobalBlack()

  case class UserBlack(user: String)

  class Service(val actor: ActorRef) {
    implicit val timeOut = Timeout(2.second)

    def globalBlackList(): Future[Map[String, SlaveInfo]] = (actor ? GlobalBlack()).mapTo[Map[String, SlaveInfo]]
  }

  def mkService(actorRef: ActorRef): Service = new Service(actorRef: ActorRef)

}

class BlackListActor(slaveInfoService: SlaveInfoActor.Service) extends Actor with ActorLogging {

  import BlackListActor._

  // 代理网络校验使用单独的线程池，避免堵塞对其他的任务造成影响
  private def mkThreadPool() = java.util.concurrent.Executors.newFixedThreadPool(32)

  private def mkExecution() = scala.concurrent.ExecutionContext.fromExecutor(threadPool)

  private          val threadPool                = mkThreadPool()
  private implicit val blackListExecutionContext = mkExecution()

  private val blackListLog = LoggerFactory.getLogger("blackList")

  private case class DoCheckProxyCanUse()

  private case class CheckResult(slaveInfo: SlaveInfo, result: Try[Any])

  private var globalBlackList: Map[String, SlaveInfo] = Map()
  private var checkFuture    : Future[Any]            = Future.successful {}
  private val doCheckTimer                            = context.system.scheduler.schedule(5.second, 5.second) {
    self ! DoCheckProxyCanUse()
  }(context.dispatcher)


  @throws[Exception](classOf[Exception])
  override def postStop(): Unit = {
    doCheckTimer.cancel()
  }

  //通过代理去访问网络，校验代理是否可用
  private def checkProxyCanUse(slaveInfo: SlaveInfo): CheckResult = {
    import scalaj.http._

    val result = Try {
      Http("http://www.baidu.com")
        .proxy(slaveInfo.ip, slaveInfo.squid_port.toInt).asString.body
    }
    CheckResult(slaveInfo, result)
  }

  private var doCheckNumber = 0

  override def receive: Actor.Receive = {
    case GlobalBlack()        =>
      sender() ! globalBlackList
    case DoCheckProxyCanUse() =>
      //只有在上传校验完成之后才会进行新的一轮代理校验
      if (checkFuture.isCompleted) {
        checkFuture =
          slaveInfoService.all()
            .map(_.values.map(slaveInfo => {
              Future(checkProxyCanUse(slaveInfo))
            }))
            .flatMap(x => Future.sequence(x))
            .map(_.foreach(self ! _))
        doCheckNumber = 0
      } else {
        doCheckNumber = doCheckNumber + 1
        blackListLog.info(s"in the do check $doCheckNumber")
      }

    case CheckResult(slaveInfo, Success(e)) =>
      import slaveInfo._
      blackListLog.info(s"check proxy success name:$slaveName ,ip:$ip")
      globalBlackList = globalBlackList - slaveInfo.slaveName

    //当通过代理访问网络失败的时候就将其加入黑名单
    case CheckResult(slaveInfo, Failure(e)) =>
      import slaveInfo._
      blackListLog.warn(s"check proxy failure name:$slaveName ,ip:$ip")
      globalBlackList = globalBlackList + (slaveInfo.slaveName -> slaveInfo)
  }
}
