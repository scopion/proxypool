package articleDegree.master.service

import scala.concurrent.Future
import scala.concurrent.duration._

import akka.actor._
import akka.pattern._
import akka.util.Timeout
import articleDegree._
import articleDegree.master.MasterRedisMap._
import articleDegree.master.{MasterInfo, SlaveInfo}
import org.slf4j.LoggerFactory
import utils.Awaits.aw
import articleDegree.master.executionContext

/**
  * Created by yujieshui on 2016/4/18.
  */
object RegisteredActor {

  class Service(val actor: ActorRef) {
    implicit val timeOut = Timeout(2.second)

    def register(registeredSlave: RegisteredSlave): Future[RegisteredRespond] =
      (actor ? registeredSlave).mapTo[RegisteredRespond]
  }

  def mkService(actorRef: ActorRef): Service = new Service(actorRef: ActorRef)

}

//todo 优化重启时间
class RegisteredActor(slaveInfoService: SlaveInfoActor.Service,
                      masterInfo: MasterInfo) extends Actor with ActorLogging {

  private[this] val registeredLog = LoggerFactory.getLogger("registered")
  private[this] val masterVersion = masterInfo.version
  private[this] val masterName    = masterInfo.name
  private[this] val pollingTime   = 30.minute.toMillis

  private[this] def computeSlaveRestartTime(): Map[String, Long] = {
    val cacheSlaveInfoMap = slaveInfoService.all().await
    val canUseSlave =
      cacheSlaveInfoMap.filter {
        case (slaveName, slaveInfo) =>
          System.currentTimeMillis() - slaveInfo.pingTime < 10.second.toMillis
      }.values.toSeq.sortBy(_.startTime)
    val doRestartTime = pollingTime / canUseSlave.size

    val result = canUseSlave zip canUseSlave.indices.map(_ + 1).map(_ * doRestartTime) map {
      case (slave, restartTime) =>
        slave.slaveName -> restartTime
    }
    result.toMap
  }

  //  private[this] var slaveRestartTime = computeSlaveRestartTime()
  //  val doUpdateSlaveRestartTimeTimer = context.system.scheduler.schedule(0.second, 1.second) {
  //    self ! DoUpdateSlaveRestartTime()
  //  }

  case class DoUpdateSlaveRestartTime()

  override def receive: Actor.Receive = {
    case RegisteredSlave(slaveActorPath, name, ip, port, password, slaveVersion, startTime) =>

      //版本校验
      //只有当slave version 与master version 相同的时候才会将其加入可用列表
      if (slaveVersion != masterVersion) {
        val causeBy = Some(s"registered fail:version is different master:$masterVersion slave:$slaveVersion")
        log.info(causeBy.get)
        sender() ! RegisteredRespond(masterName, false, causeBy, -1)
      } else {
        val slaveInfo = SlaveInfo(
          slaveName = name
          , slaveActorPath = slaveActorPath
          , ip = ip.trim
          , squid_port = port.trim
          , squid_password = password.trim
          , startTime = startTime
          , pingTime = System.currentTimeMillis()
        )
        slaveInfoService.refresh(slaveInfo).await
//        registeredLog.info(s"registered slave success name:$name ip:$ip")
        sender() ! RegisteredRespond(masterName, true, None, -1)
      }

  }
}
