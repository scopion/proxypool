package articleDegree.master.service

import scala.concurrent.Future

import com.typesafe.config.ConfigFactory
import utensil.JsonTrans._
import articleDegree.master.executionContext

/**
  * Created by yujieshui on 2016/4/21.
  */
case class User(name: String, authKey: String)

object User {
  implicit val jsonFormat = JsonValue.format[User]
}

class UserService {
  val repo = database.redis.RedisMap[String, String](ConfigFactory.load().getConfig("redis"), "proxy_pool_user")

  def find(userName: String) =
    repo.get(userName).map(_.map(_.toObj[User]))

  def create(user: User): Future[Option[User]] =
    repo.insert(user.name, user.toJsonString).map(_.map(_.toObj[User]))

  def check(user: User): Future[Boolean] =
    this.find(user.name).map(_.exists(_ == user))
}
