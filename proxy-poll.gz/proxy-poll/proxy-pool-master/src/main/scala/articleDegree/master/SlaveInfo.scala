package articleDegree.master

import akka.actor.ActorRef
import articleDegree.UserEnum
import utensil.JsonTrans._

/**
  * Created by yujieshui on 2016/4/12.
  */
object SlaveInfoTag extends Enumeration with Enum2JsonValue{

}

case class LostContact(slaveName: String)

case class UseProxyClient(user: UserEnum.Value, @deprecated("use pipeTo") out: ActorRef)

case class RestartSlave(slaveName: String, restartTime: Long)

case class MasterStop()

case class GetSlaveInfo()

case class SearchIp(ip: String)

case class SlaveInfo(slaveName: String,
                     slaveActorPath: String,
                     ip: String,
                     squid_port: String,
                     squid_password: String,
                     startTime: Long,
                     pingTime: Long,
                     tag: Option[SlaveInfoTag.Value] = None
                    )


object SlaveInfo {
  implicit val jsonValueFormat = JsonValue.format[SlaveInfo]

  def toSerString(slaveInfo: SlaveInfo) = slaveInfo.toJsonString

  def formSerString(string: String) = string.toObj[SlaveInfo]
}


case class ProxyEntity(ip: String,
                       squid_port: String,
                       squid_password: String,
                       name: String
                      )

object ProxyEntity {
  implicit val jsonFormat = JsonValue.format[ProxyEntity]
}

case class MasterInfo(name: String, version: String)

case class RequestProxyEntity(user: String, authKey: String, webType: String)

object RequestProxyEntity {
  implicit val jsonFormat = JsonValue.format[RequestProxyEntity]
}