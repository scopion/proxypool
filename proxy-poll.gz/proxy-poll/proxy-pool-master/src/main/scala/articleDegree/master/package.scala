package articleDegree

/**
  * Created by yujieshui on 2016/4/5.
  */
package object master {
  implicit val executionContext =
    scala.concurrent.ExecutionContext.fromExecutor(
      java.util.concurrent.Executors.newFixedThreadPool(4))
}
//todo 产生要求squid 所有的请求在head中混入proxy-pool-auth-key 做认证