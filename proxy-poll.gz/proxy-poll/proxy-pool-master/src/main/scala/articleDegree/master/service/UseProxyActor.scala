package articleDegree.master.service

import scala.concurrent.Future
import scala.concurrent.duration._
import scala.util.{Failure, Random, Success, Try}

import akka.actor._
import akka.pattern._
import akka.util.Timeout
import articleDegree._
import articleDegree.master._
import org.slf4j.LoggerFactory

/**
  * Created by yuJieShui on 2016/4/15.
  */
object UseProxyActor {

  class Service(val actor: ActorRef) {
    implicit val timeOut = Timeout(2.second)
    def proxy(x: UseProxy): Future[Option[ProxyEntity]] =
      (actor ask x).mapTo[Option[ProxyEntity]]

    def proxy(x: RequestProxyEntity): Future[Option[ProxyEntity]] =
      (actor ask x).mapTo[Option[ProxyEntity]]

    def getSlaves(x: GetSlaveInfo): Future[List[GetSlaveInfo]] =
      (actor ask x).mapTo[List[GetSlaveInfo]]

    def findByIp(x: SearchIp): Future[SlaveInfo] =
      (actor ask x).mapTo[SlaveInfo]
  }

  def mkService(actorRef: ActorRef): Service = new Service(actorRef: ActorRef)
}

class UseProxyActor(slaveInfoService: SlaveInfoActor.Service,
                    blackListService: BlackListActor.Service) extends Actor with ActorLogging {
  private[this] val random          = new Random()
  private[this] val userProxyLog    = LoggerFactory.getLogger("userProxy")
  private[this] val completeTimeLog = LoggerFactory.getLogger("completeTime")

  override def receive: Receive = {
    //@deprecated
    case UseProxy(user) =>
      val startTime = System.currentTimeMillis()

      val result: Future[Option[ProxyEntity]] = for {
        cacheSlaveInfoMap <- slaveInfoService.alive()
        blackList <- blackListService.globalBlackList()
      } yield {
        val canUserSlave = cacheSlaveInfoMap
          .filterNot {
            case (slaveName, slaveInfo) =>
              blackList.keys.exists(_ == slaveName)
          }
          .toSeq

        val result = Try(canUserSlave(random.nextInt(canUserSlave.size))) match {
          case Success((slaveName, slaveInfo)) =>
            userProxyLog.info(s"[success] [use proxy] user:$user slaveName:${slaveInfo.slaveName} ,ip:${slaveInfo.ip} ")
            Some(ProxyEntity(slaveInfo.ip, slaveInfo.squid_port, slaveInfo.squid_password, slaveName))
          case Failure(e)                      =>
            userProxyLog.info(s"[failure] [use proxy] cause by : slaveInfo is empty $user")
            None
        }

        val endTime = System.currentTimeMillis()
        completeTimeLog.info(s"time:${endTime - startTime}")

        result
      }
      result pipeTo sender()


    case RequestProxyEntity(user: String, authKey: String, webType: String) =>
      val startTime = System.currentTimeMillis()

      val result: Future[Option[ProxyEntity]] = for {
        cacheSlaveInfoMap <- slaveInfoService.alive()
        blackList <- blackListService.globalBlackList()
      } yield {
        val canUserSlave = cacheSlaveInfoMap
          .filterNot {
            case (slaveName, slaveInfo) => blackList.keys.exists(_ == slaveName)
          }.toSeq

        val result = Try(canUserSlave(random.nextInt(canUserSlave.size))) match {
          case Success((slaveName, slaveInfo)) =>
            userProxyLog.info(s"[success] [use proxy] user:$user slaveName:${slaveInfo.slaveName} ,ip:${slaveInfo.ip} ")
            Some(ProxyEntity(slaveInfo.ip, slaveInfo.squid_port, slaveInfo.squid_password, slaveName))
          case Failure(e)                      =>
            userProxyLog.info(s"[failure] [use proxy] cause by : slaveInfo is empty $user")
            None
        }

        val endTime = System.currentTimeMillis()
        completeTimeLog.info(s"time:${endTime - startTime}")

        result
      }
      result pipeTo sender()
    case GetSlaveInfo()                                                     =>
      slaveInfoService.all() pipeTo sender()
    case SearchIp(ip)                                                       =>
      slaveInfoService.all().map(_.values.find(_.ip == ip)) pipeTo sender()
  }
}
