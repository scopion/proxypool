package articleDegree.master.service

import akka.actor.Actor
import akka.actor.Actor.Receive
import com.typesafe.config.ConfigFactory
import database.redis.RedisMap
import utensil.JsonTrans._
import akka.pattern._
import akka.actor._
import articleDegree.master.executionContext
/**
  * Created by yujieshui on 2016/4/21.
  */
case class Unavailable(ip: String, startTime: Long, endTime: Long)

object Unavailable {
  implicit val jsonFormat = JsonValue.format[Unavailable]
}

object UnavailableListActor {

  case class All()

}

class UnavailableListActor extends Actor {
  val redisConfig = ConfigFactory.load().getConfig("redis")

  import UnavailableListActor._

  val slaveInfoMap = RedisMap[String, String](redisConfig, "proxyPool_unavailableList")

  override def receive: Receive = {
    case All() =>
      slaveInfoMap.toMap pipeTo sender()
  }
}
