package articleDegree.master.controller

import akka.actor._
import akka.http.scaladsl.Http
import akka.http.scaladsl.model._
import akka.http.scaladsl.server.{Route, RouteResult}
import akka.pattern._
import akka.stream.ActorMaterializer
import articleDegree._
import articleDegree.master._
import com.typesafe.config.ConfigFactory
import utensil.JsonTrans._

import scala.concurrent.Future
import scala.concurrent.duration._
import scala.util.Try

/**
  * Created by yujieshui on 2016/4/15.
  */


class ProxyPoolController(actorSystem: ActorSystem, masterActor: ActorRef, masterIp: String) {
  implicit val actorSystem_ = actorSystem
  implicit val materializer = ActorMaterializer()
  implicit val timeOut      = 10.second: akka.util.Timeout
  type Receive = PartialFunction[HttpRequest, Future[RouteResult]]
  val authKey = ConfigFactory.load().getString("authKey")

  def proxyPoolUnavailable = RouteResult.Complete(HttpResponse(
    StatusCodes.ServiceUnavailable,
    entity = HttpEntity.apply("not have available service ")
  ))

  def queryParamBad(msg: String) = RouteResult.Complete(HttpResponse(
    StatusCodes.BadRequest,
    entity = HttpEntity.apply(msg)
  ))


  def getProxyV2: Receive = {
    case request@HttpRequest(HttpMethods.POST, Uri.Path("/v2/proxy"), _, entity: MessageEntity, _) =>
      val requestProxy = entity.dataBytes.runFold("") {
        _ + _.utf8String
      }.map(_.toObj[RequestProxyEntity])


      requestProxy.flatMap(e => (masterActor ? e).mapTo[ProxyEntity]).map(proxyEntity => {
        RouteResult.Complete(HttpResponse(StatusCodes.OK,
          entity = HttpEntity(ContentTypes.`application/json`, proxyEntity.toJsonString)))
      })

  }

  // todo add auth
  def getProxy: Receive = {
    case request@HttpRequest(HttpMethods.GET, Uri.Path("/getProxy"), _, entity: MessageEntity, _) =>

      val user = Try(UserEnum.withName(request.uri.query().get("user").get))

      if (user.isFailure)
        Future.successful(queryParamBad("user is master"))
      else {
        val askResult = (masterActor ask UseProxy(user.get)).mapTo[Option[ProxyEntity]]
        askResult.map(proxy => {
          if (proxy.isEmpty) {
            proxyPoolUnavailable
          } else {
            RouteResult.Complete(HttpResponse(
              StatusCodes.OK,
              entity = HttpEntity.apply(
                ContentTypes.`application/json`,
                proxy.toJsonString
              )))
          }
        })
      }


  }

  //  def invalidIp: Receive = {
  //    case request@HttpRequest(HttpMethods.GET, Uri.Path("/invalid/ip"), _, _, _) =>
  //      val user = UserEnum.withName(request.uri.query().get("user").get)
  //      val ip = request.uri.query().get("ip").get
  //      (masterActor ? IpInvalid(ip, user)).mapTo[Boolean].map { result =>
  //        RouteResult.Complete(HttpResponse(
  //          StatusCodes.OK,
  //          entity = HttpEntity.apply(s"""{"result":$result}""")
  //        ))
  //      }
  //  }

  def slaveInfo: Receive = {
    case request@HttpRequest(HttpMethods.GET, Uri.Path("/slaveInfo"), _, _, _) =>
      val authKey = request.uri.query().get("authKey").get
      require(this.authKey == authKey)
      (masterActor ? GetSlaveInfo()).mapTo[Seq[SlaveInfo]].map(result => {
        RouteResult.Complete(HttpResponse(
          StatusCodes.OK,
          entity = HttpEntity.apply(ContentTypes.`application/json`, result.toJsonString)
        ))
      })
  }

  def searchIp: Receive = {
    case request@HttpRequest(HttpMethods.GET, Uri.Path("/search/ip"), _, _, _) =>
      val ip = request.uri.query().get("ip").get
      (masterActor ? SearchIp(ip)).mapTo[Option[SlaveInfo]].map(result => {
        RouteResult.Complete(HttpResponse(
          StatusCodes.OK,
          entity = HttpEntity.apply(ContentTypes.`application/json`, result.toJsonString)
        ))
      })
  }

  def other404: Receive = {
    case _ =>
      Future.successful(
        RouteResult.Complete(HttpResponse(
          StatusCodes.NotFound
        ))
      )
  }

  def haproxyHealth: Receive = {
    case request@HttpRequest(HttpMethods.GET, Uri.Path("/haproxy/health"), _, _, _) =>
      Future.successful(RouteResult.Complete(HttpResponse(
        StatusCodes.OK
      )))
  }

  val proxy: Route     = Route { context =>
    val request: HttpRequest = context.request

    (getProxy orElse haproxyHealth orElse slaveInfo orElse searchIp orElse other404).apply(request)
  }
  val master_http_port = ConfigFactory.load().getInt("master_http_port")

  val binding = Http(actorSystem).bindAndHandle(
    handler = proxy,
    interface = masterIp,
    port = master_http_port
  )
}
