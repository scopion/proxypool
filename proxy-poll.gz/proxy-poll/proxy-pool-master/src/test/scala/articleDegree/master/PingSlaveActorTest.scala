//package articleDegree.master
//
//import akka.actor.Actor.Receive
//import akka.actor.ActorSystem
//import com.typesafe.config.{ConfigFactory, ConfigValueFactory}
//import org.scalatest.FunSuite
//import akka.actor._
//import articleDegree.RemoteAddressExtension
//import akka.pattern._
//import utils.Awaits.aw
//import scala.concurrent.duration._
//
///**
//  * Created by yuJieShui on 2016/4/14.
//  */
//class PingSlaveActorTest extends FunSuite {
//  val as1 = ActorSystem("a", ConfigFactory.load().getConfig("akka_remote")
//    .withValue("akka.remote.netty.tcp.port", ConfigValueFactory.fromAnyRef(26001)))
//
//  val as2 = ActorSystem("b", ConfigFactory.load().getConfig("akka_remote")
//    .withValue("akka.remote.netty.tcp.port", ConfigValueFactory.fromAnyRef(26002)))
//  test("test") {
//    val slaveName = "aaa"
//    val slaveActor = as2.actorOf(Props(new Actor {
//      override def receive: Receive = {
//        case _ =>
//      }
//    }))
//    val slaveActorPath = ActorPath.fromString(
//      slaveActor.path.toStringWithAddress(
//        RemoteAddressExtension.apply(as2).address
//      )
//    )
//    val pingSlaveActor = as1.actorOf(Props(new Actor {
//      context.actorOf(Props(new PingSlaveActor(slaveName, slaveActorPath)))
//      var result = false
//
//      override def receive: Receive = {
//        case LostContact(name) =>
//          assert(name == slaveName)
//          result = true
//        case _ =>
//          sender() ! result
//      }
//    }))
//    implicit val t = 10.second:akka.util.Timeout
//    Thread.sleep(300)
//    as2.stop(slaveActor)
//    as2.terminate()
//    Thread.sleep(1000)
//    assert(
//      pingSlaveActor.ask(1).mapTo[Boolean].await == true
//    )
//  }
//}
