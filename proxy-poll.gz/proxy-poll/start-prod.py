from script.Machine import prodMasterMachine,prodSlaveMachine
from script.SSH import sshTo


def startSlave(machine):
    ssh = sshTo(machine)
    cmd = "sh /data/proxy-pool/slave-start.sh "
    stdin, stdout, stderr = ssh.exec_command(cmd)
    for out in stderr.readlines(): print(out)
    print("start " + machine.host)


def startMaster(machine):
    ssh = sshTo(machine)
    cmd = "sh /data/proxy-pool/master-start.sh"
    stdin, stdout, stderr = ssh.exec_command(cmd)
    for out in stderr.readlines(): print(out)
    print("start " + machine.host)


# for machine in prodMasterMachine:
#     startMaster(machine)

for machine in prodSlaveMachine:
    startSlave(machine)
