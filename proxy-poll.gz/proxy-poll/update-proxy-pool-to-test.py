import script
from script.Machine import testSlaveMachine, slaveList, testMasterMachine
from script.SSH import sshTo, sftpTo
import paramiko
import thread
import thread
from multiprocessing import Pool
from multiprocessing.dummy import Pool as ThreadPool

masterPool = ThreadPool(len(testMasterMachine))
slavePool = ThreadPool(len(testSlaveMachine))

proxyPoolPath = "/data/proxy-pool/"


def uploadFileToMaster(machine):
    t, sftp = sftpTo(machine)
    proxyPoolFile = "proxy-pool.zip"
    print ("update proxy-pool.zip to master ip:" + machine.id())
    sftp.put(localpath=r"proxy-pool-master/proxy-pool.zip", remotepath=proxyPoolPath + proxyPoolFile)
    print ("update proxy-pool.zip to master successful ip:" + machine.id())


def uploadFileToSlave(machine):
    t, sftp = sftpTo(machine)
    proxyPoolFile = "proxy-pool.zip"
    print ("update proxy-pool.zip to slave ip:" + machine.id())
    sftp.put(localpath=r"proxy-pool-slave/proxy-pool.zip", remotepath=proxyPoolPath + proxyPoolFile)
    print ("update proxy-pool.zip to slave successful ip:" + machine.id())


# needUploadToMaster = raw_input("are you want to upload to prod master [y|n]:")
# if needUploadToMaster == "y":
masterPool.map(uploadFileToMaster, testMasterMachine)

# needUploadToSlave = raw_input("are you want ot upload to prod slave  [y|n]:")
# if needUploadToSlave == "y":
slavePool.map(uploadFileToSlave, testSlaveMachine)
