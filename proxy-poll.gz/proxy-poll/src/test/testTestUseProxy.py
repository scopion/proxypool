import urllib
import re

ipRe = "[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+"

ipMap = {}

def getProxy():
    r = range(1, 10000)
    for i in r:
        f = urllib.urlopen("http://115.28.25.240:9999/getProxy?user=b")
        s = f.read()
        try:
            # ip = re.search(ipRe, s).group()
            # if ipMap.has_key(ip):
            #     ipMap[ip] = ipMap[ip] + 1
            # else:
            #     ipMap[ip] = 1
            print (s)
        except:
            ""

getProxy()
