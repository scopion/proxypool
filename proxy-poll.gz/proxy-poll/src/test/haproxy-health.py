import urllib
import re

url ="http://115.28.25.240:9001/haproxy/health"

f = urllib.urlopen(url)
s = f.read()
print (s)