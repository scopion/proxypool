import urllib
import re
import datetime

ipRe = "[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+"

ipMap = {}


def getProxy():
    while True:
        f = urllib.urlopen("http://115.28.30.163:9999/getProxy?user=b")
        s = f.read()
        try:
            ip = re.search(ipRe, s).group()
            if ipMap.has_key(ip):
                ipMap[ip] = ipMap[ip] + 1
            else:
                ipMap[ip] = 1
                print (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " --- " + s)
        except:
            ""


getProxy()
for ip in ipMap:
    print(ip)

# def invalidIp():
#     for ip in ipMap.keys():
#         f = urllib.urlopen("http://115.28.30.163:9999/invalid/ip?user=b" + "&ip=" + ip)
#         print(f.read())
#
#
# invalidIp()
