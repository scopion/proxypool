import akka.actor.{Props, ActorSystem}
//import articleDegree.master.MasterActor
import articleDegree.slave.LocalGrandActor
import com.typesafe.config.{ConfigValueFactory, ConfigFactory}
import utils.Utils

/**
  * Created by yujieshui on 2016/4/12.
  */
class ReleaseVersion extends org.scalatest.FunSuite {
  def mkMaster(port: Int) = {
    val masterIp = Utils.getIp()
    implicit val actorSystem = ActorSystem("articleDegreeMaster",
      ConfigFactory.load()
        .getConfig("articleDegree.master")
        .withValue("akka.remote.netty.tcp.hostname", ConfigValueFactory.fromAnyRef(masterIp))
        .withValue("akka.remote.netty.tcp.port", ConfigValueFactory.fromAnyRef(port))
    )

    actorSystem
  }

  val master_one_conf = ConfigFactory.load().getConfig("articleDegree.master")
    .withValue("master_version", ConfigValueFactory.fromAnyRef("1"))
  val master_two_conf = ConfigFactory.load().getConfig("articleDegree.master")
    .withValue("master_version", ConfigValueFactory.fromAnyRef("2"))

  val slave_one_conf = ConfigFactory.load().getConfig("articleDegree.slave")
    .withValue("slave_version", ConfigValueFactory.fromAnyRef("1"))
  val slave_two_conf = ConfigFactory.load().getConfig("articleDegree.slave")
    .withValue("slave_version", ConfigValueFactory.fromAnyRef("2"))


  test("release") {
    val master_one = mkMaster(25521)
    val master_two = mkMaster(25522)

//    val master_one_actor = master_one.actorOf(Props(new MasterActor(master_one_conf)))
//    val master_two_actor = master_two.actorOf(Props(new MasterActor(master_two_conf)))

    val grandSystem = ActorSystem("localGrandActorSystem")

    val slave_one_actor = grandSystem.actorOf(Props(new LocalGrandActor(slave_one_conf)))
//    val slave_two_actor = grandSystem
  }
}
