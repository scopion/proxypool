/**
  * Created by yuJieShui on 2016/4/14.
  */

import akka.actor.Actor.Receive
import akka.actor._
import articleDegree.RemoteAddressExtension
import com.typesafe.config.{ConfigFactory, ConfigValueFactory}

import concurrent.duration._
import scala.concurrent.Await
import scala.concurrent.duration.Duration.Inf

class AkkaRemoveTest extends org.scalatest.FunSuite {
  val as1 = ActorSystem("a", ConfigFactory.load().getConfig("akka_remote")
    .withValue("akka.remote.netty.tcp.port", ConfigValueFactory.fromAnyRef(26001)))

  val as2 = ActorSystem("b", ConfigFactory.load().getConfig("akka_remote")
    .withValue("akka.remote.netty.tcp.port", ConfigValueFactory.fromAnyRef(26002)))


  test("a") {
    val aa = as1.actorOf(Props(new Actor {
      override def receive: Receive = {
        case i: Int =>
          println("aaa")
      }
    }), "a")

    val bb = as2.actorOf(Props(new Actor {


      override def receive: Receive = {
        case i: Int =>
        case actorRef :ActorRef =>
          context.watch(actorRef)
        case Terminated(actor) =>
          println(actor)
      }
    }), "b")
    val watch = Await.result(
      as2.actorSelection(aa.path.toStringWithAddress(RemoteAddressExtension.apply(as1).address)).resolveOne(1.second),
      Inf
    )
    as1.stop(aa)

    Thread.sleep(1000)
  }
}
