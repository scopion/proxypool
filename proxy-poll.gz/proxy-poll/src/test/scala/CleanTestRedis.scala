import scala.util.Try

import com.typesafe.config.ConfigFactory

/**
  * Created by yujieshui on 2016/4/15.
  */
class CleanTestRedis extends org.scalatest.FunSuite {
  test("aa") {
      import collection.JavaConversions._
      import collection.JavaConverters._
      import utils.Awaits.aw
      val redisConfig = ConfigFactory.load("test/application-master.conf").getConfig("redis")
      val master_redis_map_name = ConfigFactory.load().getConfig("master_redis_map_name")
      val redis = database.redis.RedisKeyValue.apply[String, String](redisConfig)
      List(
        master_redis_map_name.getString("slaveMap")
        , master_redis_map_name.getString("user_a_map")
        , master_redis_map_name.getString("user_b_map")
        , master_redis_map_name.getString("user_c_map")
        , master_redis_map_name.getString("waitRestartSlaveMap")
        , master_redis_map_name.getString("slaveInfo")
      ).foreach(key => {
        val a =

          Try {
            redis.del(key).await

          }.toOption
      })
  }
}
