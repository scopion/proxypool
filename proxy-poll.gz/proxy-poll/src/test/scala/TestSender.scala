//import java.util.UUID
//
//import akka.actor.Actor.Receive
//import akka.actor._
//import articleDegree.RemoteAddressExtension
//import com.typesafe.config.ConfigFactory
//
///**
//  * Created by yujieshui on 2016/4/8.
//  */
//
//import akka.pattern._
//
//case class RegisteredSlave(name: String)
//
//class MasterActor extends Actor {
//
//  val remoteAddr = RemoteAddressExtension(context.system).address
//  val remotePath = self.path.toStringWithAddress(remoteAddr)
//
//  println(remotePath)
//  var slaves = Map[String, ActorPath]()
//
//  override def receive: Receive = {
//    case RegisteredSlave(name) =>
//      slaves = slaves + (name -> sender().path)
//
//    case "sayHello" =>
//      slaves.foreach {
//        case (name, path) =>
//          context.actorSelection(path) ! "hello"
//      }
//  }
//}
//
//class SlaveActor(masterActorPath: ActorPath) extends Actor {
//  val name = UUID.randomUUID()
//  context.actorSelection(masterActorPath) ! name
//
//  override def receive: Actor.Receive = {
//    case "hello" =>
//      println("hello " + name)
//  }
//}
//
//class TestSender extends org.scalatest.FunSuite {
//  val masterActorSystem = ActorSystem("master", ConfigFactory.load().getConfig("articleDegree.master"))
//  val slaveActorSystem  = ActorSystem("slave", ConfigFactory.load().getConfig("articleDegree.slave"))
//
//
//  test("test") {
//    val master = masterActorSystem.actorOf(Props(new MasterActor))
//
//    //    val actor = actorSystem.actorOf(Props(new TestActor))
//    //    val actorB = actorSystem.actorOf(Props(new Test2Actor(actor.path)))
//    //    actorB ! 1
//
//    Thread.sleep(1000000)
//
//
//  }
//}
