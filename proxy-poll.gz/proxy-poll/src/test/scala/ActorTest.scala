import scala.util.{Failure, Success}

import akka.actor.Actor.Receive
import akka.actor._
import akka.pattern._
import com.typesafe.config.{ConfigValueFactory, ConfigFactory}

/**
  * Created by yujieshui on 2016/4/11.
  */
class ActorTest extends org.scalatest.FunSuite {
  test("actor system config") {
    val config =
      ConfigFactory.load().withValue("akka.port", ConfigValueFactory.fromAnyRef(9999))
    println(
      config.getInt("akka.port")
    )
  }
  val actorSystem = ActorSystem("testSystem")

  test("acotr test") {

    val a1 =
      actorSystem.actorOf(Props(new Actor {
        var a2: ActorRef = null

        def waitInit: Receive = {
          case a2: ActorRef =>
            this.a2 = a2
            context.become(run)

        }

        override def receive: Receive = waitInit

        def run: Receive = {
          case i: Int if i > 1000 =>
            context.stop(self)
          case i: Int             =>
            println(i)
            a2 ! (i + 1)
        }

      }))

    val a2 =
      actorSystem.actorOf(Props(new Actor {
        var a1: ActorRef = null

        def waitInit: Receive = {
          case a1: ActorRef =>
            this.a1 = a1
            context.become(run)

        }

        override def receive: Receive = waitInit

        def run: Receive = {
          case i: Int if i > 1000 =>
            context.stop(self)
          case i: Int             =>
            println(i)
            a1 ! (i + 1)
        }

      }))

    a2 ! a1
    a1 ! a2
    a1 ! 1
    Thread.sleep(10000)
  }

  import scala.concurrent.duration._
  import scala.concurrent.ExecutionContext.Implicits.global

  test("send") {
    import scala.concurrent.duration._
    import scala.concurrent.ExecutionContext.Implicits.global
    implicit val timeOut = 10.second: akka.util.Timeout
    class ClientActor extends Actor {
      override def receive: Actor.Receive = {
        case a: ActorRef => a ! "hello"
      }
    }
    val a1 = actorSystem.actorOf(Props(new Actor {
      val clientActor = context.actorOf(Props(new ClientActor))

      override def receive: Actor.Receive = {
        case _ =>
          clientActor ! sender()
      }
    }))
    import utils.Awaits.aw
    println((a1 ? "").await)

  }

  test("?time out") {
    implicit val timeOut = 1.second: akka.util.Timeout
    val a = actorSystem.actorOf(Props(new Actor {
      override def receive: Actor.Receive = {
        case _ =>
      }
    }))
    (a ? 1).onComplete {
      case Success(x) => println("success")
      case Failure(x) => println("failure")
    }
    Thread.sleep(2000)
  }


}
