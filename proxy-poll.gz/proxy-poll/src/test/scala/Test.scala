import akka.actor._
import akka.pattern.ask
import articleDegree._
import articleDegree.master.{ProxyEntity, MasterActor}
import articleDegree.slave.LocalGrandActor
import com.typesafe.config.{ConfigFactory, ConfigValueFactory}
import utils.Awaits.aw

import scala.collection.JavaConversions._
import scala.concurrent.Await
import scala.concurrent.duration.{Duration, _}
import scala.util.{Success, Try}

/**
  * Created by yujieshui on 2016/4/1.
  */
class Test extends org.scalatest.FunSuite {


  val master_one_conf = ConfigFactory.load().getConfig("articleDegree.master")
    .withValue("master_restart_slave_time", ConfigValueFactory.fromAnyRef(4))
    .withValue("akka.remote.netty.tcp.hostname", ConfigValueFactory.fromAnyRef("127.0.0.1"))


  val slave_one_conf = ConfigFactory.load().getConfig("articleDegree.slave")
    .withValue("akka.remote.netty.tcp.port", ConfigValueFactory.fromAnyRef(25001))
    .withValue("akka.remote.netty.tcp.hostname", ConfigValueFactory.fromAnyRef("127.0.0.1"))
    .withValue("asDug", ConfigValueFactory.fromAnyRef(true))
    .withValue("doRestartTimeBase", ConfigValueFactory.fromAnyRef(10))
    .withValue("doRestartTimeFlat", ConfigValueFactory.fromAnyRef(10))
    .withValue("restartTime", ConfigValueFactory.fromAnyRef(10))
    .withValue("masterActorPaths", ConfigValueFactory.fromIterable(
      List("akka.tcp://articleDegreeMaster@127.0.0.1:2552/user/masterActor")
    ))
  implicit val actorSystem = ActorSystem("articleDegreeMaster", master_one_conf)
  val grandSystem = ActorSystem("grand")

  implicit val timeOver: akka.util.Timeout = 100.second

  lazy val grandActor_one = grandSystem.actorOf(Props(new LocalGrandActor(slave_one_conf)))
  lazy val masterActor    = actorSystem.actorOf(Props(new MasterActor(master_one_conf)), "masterActor")

  test("clean") {
    import utils.Awaits.aw
    val redisConfig = ConfigFactory.load().getConfig("redis")
    val master_redis_map_name = ConfigFactory.load().getConfig("master_redis_map_name")
    val redis = database.redis.RedisKeyValue.apply[String, String](redisConfig)
    List(
      master_redis_map_name.getString("slaveMap")
      , master_redis_map_name.getString("user_a_map")
      , master_redis_map_name.getString("user_b_map")
      , master_redis_map_name.getString("user_c_map")
      , master_redis_map_name.getString("waitRestartSlaveMap")
      , master_redis_map_name.getString("slaveInfo")
    ).foreach(key => {
      val a =

        Try {
          redis.del(key).await

        }.toOption
    })
    masterActor
    grandActor_one
    println(masterActor.path)
    Thread.sleep(1000)
  }
  test("test use proxy") {
    Thread.sleep(1000)

    1 to 10 map { _ =>
      val Success((result: Option[ProxyEntity])) = Try((masterActor ? UseProxy(UserEnum.a)).mapTo[Option[ProxyEntity]].await)
      assert(result.nonEmpty)
      result
    }
    1 to 10 map { _ =>
      val Success((result: Option[ProxyEntity])) = Try((masterActor ? UseProxy(UserEnum.b)).mapTo[Option[ProxyEntity]].await)
      assert(result.nonEmpty)
      result
    }
  }
  //  test("invalid ip") {
  //    val Success((proxyEntity: Option[ProxyEntity])) = Try((masterActor ? UseProxy(UserEnum.c)).mapTo[Option[ProxyEntity]].await)
  //    assert(proxyEntity.nonEmpty)
  //    val Success(invalid_result: Boolean) = Try((masterActor ? IpInvalid(proxyEntity.get.ip, UserEnum.c)).mapTo[Boolean].await)
  //    assert(invalid_result)
  //
  //  }
  test("use proxy is empty") {
    Thread.sleep(18000)
    val Success((proxyEntity_c: Option[ProxyEntity])) = Try((masterActor ? UseProxy(UserEnum.c)).mapTo[Option[ProxyEntity]].await)
    val Success((proxyEntity_b: Option[ProxyEntity])) = Try((masterActor ? UseProxy(UserEnum.b)).mapTo[Option[ProxyEntity]].await)
    val Success((proxyEntity_a: Option[ProxyEntity])) = Try((masterActor ? UseProxy(UserEnum.a)).mapTo[Option[ProxyEntity]].await)
    assert(proxyEntity_c.isEmpty)
    assert(proxyEntity_b.isEmpty)
    assert(proxyEntity_a.isEmpty)
  }
  test("after restart") {
    Thread.sleep(20000)
    //    import akka.do
    val Success((proxyEntity_c: Option[ProxyEntity])) = Try((masterActor ? UseProxy(UserEnum.c)).mapTo[Option[ProxyEntity]].await)
    val Success((proxyEntity_b: Option[ProxyEntity])) = Try((masterActor ? UseProxy(UserEnum.b)).mapTo[Option[ProxyEntity]].await)
    val Success((proxyEntity_a: Option[ProxyEntity])) = Try((masterActor ? UseProxy(UserEnum.a)).mapTo[Option[ProxyEntity]].await)
    assert(proxyEntity_c.nonEmpty)
    assert(proxyEntity_b.nonEmpty)
    assert(proxyEntity_a.nonEmpty)
    Thread.sleep(10000)

  }

  test("kill slave") {
    grandSystem.stop(grandActor_one)
    grandSystem.terminate()
    Await.result(grandSystem.whenTerminated, Duration.Inf)
  }

  test("master stop_") {
    actorSystem.stop(masterActor)
    //    val new_masterActor    = actorSystem.actorOf(Props(new MasterActor(master_one_conf)), "masterActor")

    Thread.sleep(3000)
  }

  //  test("stop slave"){
  //    grandActor_one ! PoisonPill
  //    Thread.sleep(1000)
  //    val Success((proxyEntity_c: Option[ProxyEntity])) = Try((masterActor ? UseProxy(UserEnum.c)).mapTo[Option[ProxyEntity]].await)
  //    val Success((proxyEntity_b: Option[ProxyEntity])) = Try((masterActor ? UseProxy(UserEnum.b)).mapTo[Option[ProxyEntity]].await)
  //    val Success((proxyEntity_a: Option[ProxyEntity])) = Try((masterActor ? UseProxy(UserEnum.a)).mapTo[Option[ProxyEntity]].await)
  //    assert(proxyEntity_c.isEmpty)
  //    assert(proxyEntity_b.isEmpty)
  //    assert(proxyEntity_a.isEmpty)
  //  }


  test("master stop") {
    grandActor_one
    masterActor
    actorSystem.stop(masterActor)
    actorSystem.terminate()
    actorSystem.whenTerminated.await
    //    println((masterActor ? MasterStop()).await)
  }

}
