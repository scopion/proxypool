import akka.actor.Actor.Receive
import akka.actor.{Actor, Props, ActorSystem}
import org.slf4j.LoggerFactory
import akka.actor._

/**
  * Created by yuJieShui on 2016/4/9.
  */
class TestLog extends org.scalatest.FunSuite {
  test("log") {
    val logger = LoggerFactory.getLogger("testLog")

    logger.info("hello")
  }
  test("log actor") {
    ActorSystem("logTest").actorOf(Props(new Actor with ActorLogging {
      log.info("aaa")
      override def receive: Receive = {
        case _ =>
      }
    }))
  }
}
