import scala.concurrent.{Await, Future}
import scala.util.Try

import akka.actor.ActorSystem
import concurrent.duration._

/**
  * Created by yujieshui on 2016/4/18.
  */
object CancellableTest extends App {
  implicit var exe =
    scala.concurrent.ExecutionContext.fromExecutor(
      java.util.concurrent.Executors.newFixedThreadPool(4))

  val blockTask =
    1 to 5 map { i =>
      Future{
        println(i)
        while (true) {
          val i = 1 + 1
        }
      }
    }
  Thread.sleep(5000)
  blockTask.map(f=>Try(Await.ready(f,0.second)))
  println("------")

  exe.execute(new Runnable {
    override def run(): Unit = {
      println("end")
    }
  })

}
