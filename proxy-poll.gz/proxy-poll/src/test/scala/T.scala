import java.io.File

import scala.io.Source

/**
  * Created by yuJieShui on 2016/4/16.
  */
object T extends App {
  val s   =
    Source.fromFile(new File("F:\\nohup.out")).getLines()
  val r   = "\\[articleDegree\\.master\\.Master2\\] - registered slave success name:119\\.161\\.229\\.251:20161  ip:(.*)".r
  val ips =
    s.map(_.split("registered slave success name")).filter(_.size > 1).map(_.last.split("ip:").last)
      .toSeq.groupBy(e => e).keys
  println(
    ips.mkString("\n")
  )
}
