package testTestService

import scala.util.Try
import scalaj.http.{HttpResponse, Http}

import com.decodified.scalassh.SSH.Result
import com.decodified.scalassh._
import articleDegree.master.{ProxyEntity, SlaveInfo}
import model.Machine
import utensil.JsonTrans._

/**
  * Created by yujieshui on 2016/4/20.
  */

trait Base {
  def getProxy(user: String = "c"): HttpResponse[String] = {
    Http(s"http://115.28.25.240:9999/getProxy?user=${user}").timeout(5000, 5000).asString
  }


  def checkProxy(proxyEntity: ProxyEntity): Try[String] = {
    Try {
      Http("http://www.baidu.com")
        .proxy(proxyEntity.ip, proxyEntity.squid_port.toInt).asString.body
    }
  }

  def sshTo[T](machine: Machine): ((SshClient) => Result[T]) => Validated[T] = {
    val hostConfig = HostConfig(
      login = PasswordLogin(machine.username, SimplePasswordProducer(machine.password))
      , hostName = machine.host
      , port = machine.port
    )
    SSH(machine.host, hostConfig) _
  }

  implicit class  `Validated[CommandResult] with out`(x: Validated[CommandResult])  {
    def out[V](f: CommandResult => V) = {
      x.right.map(e => println(f(e)))
    }
  }

}
