package testTestService

import scala.util.Try

import akka.actor.ActorSystem
import articleDegree.master.ProxyEntity
import com.decodified.scalassh.{SimplePasswordProducer, PasswordLogin, HostConfig, SSH}
import com.typesafe.config.ConfigFactory
import database.redis.RedisKeyValue
import model.Machine
import utensil.JsonTrans._
import utensil.Await.aw

/**
  * Created by yujieshui on 2016/4/20.
  */
class Main extends org.scalatest.FunSuite with Base {
  val startSalveCmd  = "sh /data/proxy-pool/slave-start.sh"
  val startMasterCmd = "sh /data/proxy-pool/master-start.sh"

  val stopSquidCmd  = "ps -ef | grep squid | grep -v grep | cut -c 9-15 | xargs kill -s 9"
  val startSquidCmd = "squid start"

  val stopSlaveCmd  = "ps -ef | grep articleDegree | grep -v grep | cut -c 9-15 | xargs kill -s 9"
  val stopMasterCmd = "ps -ef | grep articleDegree | grep -v grep | cut -c 9-15 | xargs kill -s 9"

  test("clean") {
    Machine.Test.slave.foreach(machine => sshTo(machine) { client =>
      client.exec(stopSlaveCmd)
    })

    Machine.Test.master.foreach(machine => sshTo(machine) { client =>
      client.exec(stopMasterCmd)
    })
    RedisKeyValue.apply[String, String](ConfigFactory.load().getConfig("redis")).redisClient.flushall().await
    Machine.Test.master.foreach(machine => sshTo(machine) { client =>
      client.exec(startMasterCmd).right.map(result => println(result.stdOutAsString()))
    })
    Machine.Test.slave.foreach(machine => sshTo(machine) { client =>
      client.exec(startSalveCmd).right.map(result => println(result.stdOutAsString()))
    })
    def waitServiceCanUse(): Unit = {
      val t = Try(getProxy().body.toObj[ProxyEntity]).filter(_.name.trim == Machine.Test.slave.last.name)
      if (t.isSuccess)
        ()
      else
        waitServiceCanUse()
    }
    waitServiceCanUse()
  }

  def proxyList() = 1 to 100 map (_ => (getProxy()))

  test("use proxy") {
    val proxys = proxyList()
      .map(e => Try(e.body.toObj[ProxyEntity]))
      .filter(_.isSuccess)
      .map(_.get)
      .groupBy(_.ip).keys.toList
    assert(proxys.size == Machine.Test.slave.size)

    val x = proxyList()
      .map(_.body)
      .map(e => e.toObj[ProxyEntity])
      .groupBy(e => e).keys.toList

    assert(x map checkProxy forall (_.isSuccess))
  }
  test("proxy uniform distribution") {
    val x =
      1 to 300 map (_ => getProxy()) map (_.body.toObj[ProxyEntity]) groupBy (_.ip)
    val average = 300 / x.size
    assert(x.size > 1)
    val r = x.map(_._2.size.toDouble / average)
    println(r)
    assert(r.forall(e => e > 0.9 && e < 1.1))
  }

  test("slave shutdown java") {
    sshTo(Machine.Test.slave.head) { client =>
      client.exec(stopSlaveCmd).right.map(result => println(result.stdOutAsString()))
      Thread.sleep(6000)


    }
    val x = proxyList().map(_.body).groupBy(e => e).keys

    assert(x.size == 1)
    assert(x.head.toObj[ProxyEntity].name != Machine.Test.slave.head.name)

    sshTo(Machine.Test.slave.head) { client =>
      client.exec(startSalveCmd).right.map(result => println(result.stdOutAsString()))
    }
    while (getProxy().body.toObj[ProxyEntity].name.trim != Machine.Test.slave.head.name.trim) {}

  }
  test("slave shutdown squid") {
    sshTo(Machine.Test.slave.last) { client =>
      client.exec(stopSquidCmd).out(_.stdOutAsString())


    }
    try {
      Thread.sleep(4000)
      val x = proxyList().map(_.body).groupBy(e => e).keys
      assert(x.size == 1)
      assert(x.head.toObj[ProxyEntity].name != Machine.Test.slave.last.name)

    } finally {
      sshTo(Machine.Test.slave.last) { client =>
        client.exec(startSquidCmd).right.map(result => {
          println(result.stdOutAsString())
          println(result.stdErrAsString())
        })
      }
    }

  }
  test("shutdown master") {
    sshTo(Machine.Test.master.head) { client =>
      client.exec(stopMasterCmd).out(_.stdOutAsString())
      Thread.sleep(1000)
      val x = 1 to 100 map (_ => Try(getProxy().body.toObj[ProxyEntity]))
      assert(x.forall(_.isSuccess))
      client.exec(startMasterCmd).out(_.stdOutAsString())
    }
  }
  test("503") {
    Machine.Test.slave.foreach(machine => {
      sshTo(machine) { client =>
        client.exec(stopSlaveCmd).out(_.stdOutAsString())
      }
    })
    Thread.sleep(5000)
    val x =
      1 to 10 map (_ => getProxy())
    assert(x.forall(_.code == 503))

  }

  test("fix") {
    Machine.Test.slave.foreach(machine => machine.ssh { client =>
      client.exec(startSalveCmd)
    })
    Thread.sleep(5000)
    val x =
      1 to 10 map (_ => getProxy())

    assert(x.forall(_.is2xx))

  }
}
