package model

import com.decodified.scalassh.SSH.Result
import com.decodified.scalassh._

/**
  * Created by yujieshui on 2016/4/20.
  */
case class Machine(
                    host: String
                    , port: Int
                    , username: String
                    , password: String,
                    mac: String = ""
                  ) {
  def name = host + ":" + port

  def ssh[T]: ((SshClient) => Result[T]) => Validated[T] = {
    val machine = this
    val hostConfig = HostConfig(
      login = PasswordLogin(machine.username, SimplePasswordProducer(machine.password))
      , hostName = machine.host
      , port = machine.port
    )
    SSH(machine.host, hostConfig) _
  }
}

object Machine {

  object Test {
    val slave  = List(
      Machine("122.228.235.49", 21941, "root", "5c6213f1")
      , Machine("183.131.135.216", 21651, "root", "57997822")
    )
    val master = List(
      Machine("115.28.25.240", 22, "root", "YWNiMDJ1NjBjds1"),
      Machine("115.29.111.113", 22, "root", "MJc2s7uyfC6t5L5V")
    )
  }

  object Prod {
    val slave  = List(
      Machine("119.161.229.251", 20161, "root", "cd576916") //   # 1
      , Machine("119.161.229.250", 27751, "root", "2e65cfd8") // # proxy-pool-prod-slave-2
      , Machine("119.161.229.250", 27761, "root", "2685e562") // # proxy-pool-prod-slave-3
      , Machine("183.131.135.221", 22051, "root", "84267b49") // # proxy-pool-prod-slave-4
      , Machine("183.131.135.221", 22421, "root", "84267b49") // # proxy-pool-prod-slave-5
      , Machine("183.131.135.221", 22131, "root", "84267b49") // # proxy-pool-prod-slave-6
      , Machine("183.131.135.221", 22191, "root", "84267b49") // # proxy-pool-prod-slave-7
      , Machine("122.228.235.49", 20831, "root", "b8907931") //  # proxy-pool-prod-slave-8
      , Machine("122.228.235.49", 21041, "root", "b8907931") //  # proxy-pool-prod-slave-9
      , Machine("122.228.235.49", 21061, "root", "b8907931") //  # proxy-pool-prod-slave-10
      , Machine("122.228.235.49", 21071, "root", "b8907931") //  # proxy-pool-prod-slave-11
      , Machine("122.228.235.49", 21091, "root", "b8907931") //  # proxy-pool-prod-slave-12
      , Machine("122.228.235.49", 21111, "root", "b8907931") //  # proxy-pool-prod-slave-13
      , Machine("122.228.235.49", 21121, "root", "b8907931") //  # proxy-pool-prod-slave-14
    )
    val master = List(
      Machine("115.28.30.163", 22, "root", "MJc2s7uyfC6t5L5V") //    # proxy-pool-prod-master-1
      , Machine("139.129.37.227", 22, "root", "MJc2s7uyfC6t5L5V") // # proxy-pool-prod-master-2
    )
  }

}