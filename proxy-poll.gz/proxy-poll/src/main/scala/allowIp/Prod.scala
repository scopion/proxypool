package allowIp

import scala.util.Try

import model.Machine

/**
  * Created by yujieshui on 2016/4/21.
  */

object Prod extends App with Base {

  val masterCmd = Machine.Prod.master
    .map(_.host)
    .map(ip => s"iptables -I INPUT -s $ip -j ACCEPT")

  val baseRules = baseCmd ++ masterCmd ++ outSide
  Machine.Prod.slave.map(_.ssh(client => {


    val t = Try {
      client.exec(
        baseRules.mkString("\n")
      )
    }
    if (t.isFailure) {

      t.failed.get.printStackTrace()
      System.exit(0)
    }
  }))
}