import zipfile
import os

zipName = "proxy-pool.zip"
startdir = "target\\pack"
print (os.listdir(r"D:\scala-proxy-slave-lib"))
try:
    map(lambda fileName:os.remove(startdir + "\\lib\\" + fileName),os.listdir(r"D:\scala-proxy-slave-lib"))
    os.remove(zipName)
except :
    print("")
print ("zip file " + zipName)
f = zipfile.ZipFile(zipName, 'w', zipfile.ZIP_DEFLATED)

for dirpath, dirnames, filenames in os.walk(startdir):
    for filename in filenames:
        f.write(os.path.join(dirpath, filename))
f.close()
print ("zip file successful " + zipName)
