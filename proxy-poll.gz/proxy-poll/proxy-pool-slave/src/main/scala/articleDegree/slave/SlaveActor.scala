package articleDegree.slave

import java.io.File

import akka.actor.{Actor, ActorLogging, ActorPath, ActorRef, _}
import akka.pattern._
import akka.util.Timeout
import articleDegree._
import com.typesafe.config.Config
import org.joda.time.DateTime
import org.slf4j.LoggerFactory
import utils.Awaits.aw
import utils.Utils

import scala.concurrent.duration._
import scala.io.Source
import scala.util.{Random, Try}

/**
  * Created by yuJieShui on 2016/4/15.
  */
class SlaveActor(masterPathList: Seq[ActorPath],
                 localGrandActor: ActorRef,
                 config: Config
            ) extends Actor with ActorLogging {
  private[this] val startTime              = System.currentTimeMillis()
  private[this] val name          : String = Try(Source.fromFile(new File("/data/proxy-pool/slave_name")).getLines().toSeq.head).getOrElse(Utils.mac())
  private[this] val ip            : String = Utils.get_ppp0_ip().getOrElse(Utils.get_netAddress_ip())
  private[this] val squid_port    : String = "8888"
  private[this] val squid_password: String = "unknow"
  private[this] val slave_version : String = config.getString("slave_version")

  private[this] val registerLog = LoggerFactory.getLogger("register")
  private[this] val restartLog  = LoggerFactory.getLogger("restart")

  private[this] val random      = new Random()
  private[this] var masterIndex = random.nextInt(masterPathList.size)
  private[this] var masterPath  = nextMasterPath()

  private[this] final def nextMasterPath() = {
    masterIndex = (masterIndex + 1) % masterPathList.size
    log.info(s"use master as $masterIndex")
    masterPathList.apply(masterIndex)
  }

  private[this] final val afterTimeDoRestart =
    (config.getInt("doRestartTimeBase").second + random.nextInt(config.getInt("doRestartTimeFlat")).second).toMillis
  private[this] final var doRestartTime      = startTime + afterTimeDoRestart
  private[this] final val waitRestartTime    = config.getInt("waitRestartTime").second
  restartLog.info(s"do restart time : ${new DateTime(doRestartTime).toString()} ,wait time : $waitRestartTime")

  private[this] final def masterActor() = context.system.actorSelection(masterPath)


  case class DoRegister()

  case class DoCheckRestart()

  private[this] final val timerRegister = context.system.scheduler.schedule(0.second, 2.second) {
    self ! DoRegister()
  }
  private[this] final val checkRegister = context.system.scheduler.schedule(2.second, 2.second) {
    self ! DoCheckRestart()
  }


  @scala.throws[Exception](classOf[Exception])
  override def postStop(): Unit = {
    timerRegister.cancel()
    checkRegister.cancel()
  }

  override def receive: Receive = {
    case DoRegister()     =>
      val remoteAddr = RemoteAddressExtension(context.system).address.copy(protocol = "akka.tcp")
      val remotePath = self.path.toStringWithAddress(remoteAddr)

      implicit val timeOut = Timeout(10.second)
      val respond = Try(
        (
          masterActor() ? RegisteredSlave(
            slaveActorPath = remotePath,
            name = name,
            ip = ip,
            port = squid_port,
            password = squid_password,
            slaveVersion = slave_version,
            startTime = startTime
          )
          ).mapTo[RegisteredRespond].await
      ).getOrElse(RegisteredRespond("", false, Some("connect to master fail"), -1))

      if (respond.result) {

        registerLog.info(s" [success] register to master ${respond.masterName}")
        if (respond.restartTime > System.currentTimeMillis())
          doRestartTime = respond.restartTime

      } else {

        registerLog.info(
          s" [failure] register to master ${respond.masterName} " +
            s"cause by ${respond.causeBy.get} failNum:$respond connect to next master")
        masterPath = nextMasterPath()

      }
    case DoCheckRestart() =>
      if (System.currentTimeMillis() > doRestartTime) {
        timerRegister.cancel()
        checkRegister.cancel()
        log.info(s"wait restart in $waitRestartTime")
        context.become(waitRestart)
        context.system.scheduler.scheduleOnce(waitRestartTime) {
          localGrandActor ! RestartStr
        }
      }
  }

  //not do any
  def waitRestart: Receive = {
    case DoRegister()     =>
    case DoCheckRestart() =>
  }

}
