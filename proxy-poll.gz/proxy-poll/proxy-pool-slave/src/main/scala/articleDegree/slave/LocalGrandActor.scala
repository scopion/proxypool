package articleDegree.slave

import scala.collection.JavaConversions._
import scala.concurrent.Await
import scala.concurrent.duration._
import scala.io.Source
import scala.util.Try

import java.io.File

import akka.actor.{Actor, ActorPath, ActorSystem, _}
import articleDegree._
import com.typesafe.config.{Config, ConfigValueFactory}
import utils.Utils

/**
  * Created by yuJieShui on 2016/4/9.
  */
class LocalGrandActor(
                       config: Config
                     ) extends Actor with ActorLogging {
  val masterPathList = config.getStringList("masterActorPaths").toIndexedSeq
  val asDug          = Try(config.getBoolean("asDug")).getOrElse(false)
  log.info(s"adDug $asDug")
  val slaveName: String = Try(
    Source.fromFile(new File("/data/proxy-pool/slave_name")).getLines().toSeq.head
  ).getOrElse(
    Utils.mac()
  )

  def getIp() = {
    if (asDug) {
      log.info("as debug get ip")
      utils.Utils.get_ppp0_ip().getOrElse(utils.Utils.get_netAddress_ip())
    } else
      utils.Utils.get_ppp0_ip().get
  }

  @deprecated
  def ip = getIp()

  def mkSlaveSystem() = ActorSystem("articleDegreeSlave",
    config.withValue("akka.remote.netty.tcp.hostname", ConfigValueFactory.fromAnyRef(getIp()))
  )

  def mkSlaveActor() = slaveSystem.actorOf(Props(new SlaveActor(
    masterPathList.map(ActorPath.fromString), self, config
  )))

  var slaveSystem = mkSlaveSystem()

  var slaveActor = mkSlaveActor()


  @throws[Exception](classOf[Exception])
  override def postStop(): Unit = {
    slaveSystem.stop(slaveActor)
    slaveSystem.terminate()
    Await.result(slaveSystem.whenTerminated, Duration.Inf)
  }

  override def receive: Receive = {
    case RestartStr =>
      slaveSystem.stop(slaveActor)
      slaveSystem.terminate()
      Await.result(slaveSystem.whenTerminated, Duration.Inf)
      var doWhile = true
      val oldIp = getIp()
      while (doWhile) {
        log.info(s"try restart adsl now slaveName: $slaveName ip:$oldIp")
        if (asDug) {

        } else {
          Utils.restartAdsl()
        }
        while (Utils.get_ppp0_ip().isEmpty) {
          log.error("get ppp0 failure")
          Thread.sleep(1000)
        }
        val newIp = getIp()
        log.info(s"restart adsl finish now ip $newIp")
        log.info(s"restart $slaveSystem")

        val result = newIp match {
          case s: String if s == oldIp       =>
            log.error(s"new ip == old ip $oldIp")
            if (asDug) true else false
          case s: String if s == "127.0.0.1" =>
            log.error(s"new ip == 127.0.0.1")
            false
          case _                             =>
            log.info(s"new ip ${getIp()}")
            true
        }
        if (result == true) doWhile = false
      }



      slaveSystem = mkSlaveSystem()
      slaveActor = mkSlaveActor()

  }
}
