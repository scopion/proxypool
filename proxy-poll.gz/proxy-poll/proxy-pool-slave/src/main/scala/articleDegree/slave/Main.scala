package articleDegree.slave

import java.io._

import akka.actor.{ActorSystem, _}
import com.typesafe.config.ConfigFactory
import utils.Utils
import utils.Utils.pattenConfigResource


object Main {

  def main(args: Array[String]): Unit = {
    val configFile = args.toList.map(pattenConfigResource).find(_.nonEmpty).flatten.getOrElse(
      "application.conf"
    )
    System.setProperty("config.resource", configFile)

    val pidFile = new PrintWriter(new FileOutputStream(new File("/data/proxy-pool/pid")))
    pidFile.append(Utils.pid())
    pidFile.close()

    println(Utils.pid())
    println(Utils.get_ppp0_ip())
    val listenActorSystem = ActorSystem("localGrandActorSystem")
    val slaveConfig = ConfigFactory.load().getConfig("articleDegree.slave")
    listenActorSystem.actorOf(Props(new LocalGrandActor(slaveConfig)))

  }
}
