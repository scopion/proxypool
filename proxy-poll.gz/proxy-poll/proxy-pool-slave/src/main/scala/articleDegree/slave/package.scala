package articleDegree

import scala.concurrent.ExecutionContext

/**
  * Created by yujieshui on 2016/4/5.
  */
package object slave {
  implicit val exe =
    ExecutionContext.fromExecutor(
      java.util.concurrent.Executors.newFixedThreadPool(1))

  case class RestartSlaveActorSystem(slaveName: String)

}
