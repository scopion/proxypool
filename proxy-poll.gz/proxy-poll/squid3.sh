#apt-get isntall squid
yum install squid

squidConfFile='/etc/squid/squid.conf'
squidAuthFile='/usr/lib/squid/basic_ncsa_auth'

squidPasswdFile='/data/proxy-pool/squid_passwd'


squid_password='wecash:zYCdQHGJXYlys'
password='esubndsj'

#htpasswd -cd ${squidPasswdFile} wecash ${password}

cat > /data/proxy-pool/password <<-EOF
${password}
EOF

cat > ${squidPasswdFile} <<-EOF
$squid_password
EOF



cat > ${squidConfFile} <<-EOF
http_port 8888
via off
forwarded_for delete
#auth_param basic program ${squidAuthFile} ${squidPasswdFile}
#auth_param basic realm Welcome to my system
#acl auth_user proxy_auth REQUIRED
#http_access allow auth_user
#http_access deny all
http_access allow all
cache_dir ufs /var/spool/squid 100 16 256 read-only
cache_mem 0 MB
coredump_dir /var/spool/squid
dns_nameservers 223.5.5.5 223.6.6.6
EOF