### info
 - 获取代理信息
 
### url
`get /getProxy`

### request params 
 - user:String // in [a,b,c]

### code: 
 503 // 当前没有可用代理服务器
 
### result 
```json
{
    "ip":"125.109.198.35 ",
    "squid_port":"8888",
    "squid_password":"wrfughbresdwnndolfhn"
}
```