### info 
 - 当一个代理ip被封掉之后，调用此接口，
 
### url
`get /invalid/ip`

### request params 
 - user :String // in [a,b,c]
 - ip   :String // invalid ip 


### result 
```json
{
    "result":ture
}
```