# test ip : 
    115.28.25.240:9001
    
# api
 - [invalid ip](http://git.wecash.net/league/proxy-poll/wikis/invalid-ip)
 - [get proxy](http://git.wecash.net/league/proxy-poll/wikis/get-proxy)