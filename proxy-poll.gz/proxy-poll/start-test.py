from script.Machine import testSlaveMachine, slaveList, testMasterMachine
from script.SSH import sshTo, sftpTo
import time


def startSlave(machine):
    ssh = sshTo(machine)
    cmd = "sh /data/proxy-pool/slave-start.sh "
    stdin, stdout, stderr = ssh.exec_command(cmd)
    for out in stderr.readlines(): print(out)
    print("start " + machine.host)


def startMaster(machine):
    ssh = sshTo(machine)
    cmd = "sh /data/proxy-pool/master-start.sh"
    stdin, stdout, stderr = ssh.exec_command(cmd)
    for out in stderr.readlines(): print(out)
    print("start " + machine.host)


for machine in testMasterMachine:
    startMaster(machine)
#
# time.sleep(5)

for machine in testSlaveMachine:
    startSlave(machine)
