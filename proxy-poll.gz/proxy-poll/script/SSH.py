import paramiko
import Machine


def sshTo(machine):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(hostname=machine.host, port=machine.port, username=machine.username, password=machine.password)
    return ssh


def sftpTo(machine):
    t = paramiko.Transport((machine.host, machine.port))
    t.connect(username=machine.username, password=machine.password)
    sftp = paramiko.SFTPClient.from_transport(t)
    return t, sftp
