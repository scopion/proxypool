import os
def libToPath(libs, localPath, remotePath):
    result = []
    for libname in libs:
        result.append((
            localPath + libname,
            remotePath + libname
        ))
    return result

slaveLibName =os.listdir("D:\\scala-proxy-slave-lib\\")

slaveLibPath = libToPath(slaveLibName, "D:\\scala-proxy-slave-lib\\", "/data/proxy-pool/public-lib/")

masterLibName = os.listdir("D:\\scala-proxy-master-lib\\")
masterLibPath = libToPath(masterLibName, "D:\\scala-proxy-master-lib\\", "/data/proxy-pool/public-lib/")

