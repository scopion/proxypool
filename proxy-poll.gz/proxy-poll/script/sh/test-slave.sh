#!/usr/bin/env bash
mkdir /data
mkdir /data/proxy-pool
rm -f /data/proxy-pool/slave-start.sh
rm -f /data/proxy-pool/slave-stop.sh
touch /data/proxy-pool/slave-start.sh
touch /data/proxy-pool/slave-stop.sh

outFile='/data/proxy-pool/slave-start.sh'

cd /data/proxy-pool
echo 'cd /data/proxy-pool/'                     >>${outFile}
echo 'kill -9 `cat pid`'                        >>${outFile}
echo 'ps -ef | grep articleDegree | grep -v grep | cut -c 9-15 | xargs kill -s 9' >>${outFile}
echo 'rm -rf target'                            >>${outFile}
echo 'unzip proxy-pool.zip'                     >>${outFile}
echo '\cp public-lib/* target/pack/lib/'        >>${outFile}
echo 'chmod 777 ./target/pack/bin/slave'        >>${outFile}
javaFile=/usr/local/jdk1.8.0_65/bin/java
if [ -f "${javaFile}" ];then
    echo 'export JAVA_HOME=/usr/local/jdk1.8.0_65'  >>${outFile}
else
    echo 'export JAVA_HOME=/usr' >>${outFile}
fi
#java_place=`which java`
#if [ "${java_place}" = "/usr/bin/java" ];then
#    echo 'export JAVA_HOME=/usr'  >>${outFile}
#else
echo 'export JAVA_HOME=/usr/local/jdk1.8.0_65'  >>${outFile}

echo 'nohup ./target/pack/bin/slave -Dconfig.resource=test/application-slave.conf > nohup.out 2>&1 &' >>${outFile}
