from script.Machine import prodMasterMachine,prodSlaveMachine
from InitMachineCmds import InitMachine

for machine in prodSlaveMachine:
    InitMachine().prod.cmd.initSlave(machine)
    InitMachine().prod.lib.initSlave(machine)

# for machine in prodMasterMachine:
#     InitMachine().prod.cmd.initMaster(machine)
    # InitMachine().prod.lib.initMaster(machine)