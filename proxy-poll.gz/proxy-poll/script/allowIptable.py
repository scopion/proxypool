list=[
    "iptables -I INPUT -m state --state RELATED,ESTABLISHED -j ACCEPT"
    "iptables -I INPUT -i lo -j ACCEPT"
    "iptables -I INPUT  -s 127.0.0.1  -j ACCEPT"
]

"iptables -I INPUT -s  115.28.30.163  -j ACCEPT"