from script.Machine import testSlaveMachine, testMasterMachine
from InitMachineCmds import InitMachine
outMasterStart = " >>/data/proxy-pool/master-start.sh"
outSlaveStart = " >>/data/proxy-pool/slave-start.sh"

for machine in testSlaveMachine:
    InitMachine().test.cmd.initSlave(machine)
    # InitMachine().test.lib.initSlave(machine)
    # InitMachine().test.squid.initSlave(machine)

for machine in testMasterMachine:
    InitMachine().test.cmd.initMaster(machine)
    # InitMachine().test.lib.initMaster(machine)


