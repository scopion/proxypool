# coding=utf-8
class Machine:
    def __init__(self, host, port, username, password, mac=""):
        self.host = host
        self.port = port
        self.username = username
        self.password = password

    def id(self):
        return self.host + ":" + str(self.port)


slaveList = [
    Machine("183.131.135.213", 21281, "root", "11201deb")
    , Machine("122.228.235.47", 20361, "root", "a99c7807")
    , Machine("122.228.235.47", 21631, "root", "d59409d8")
    , Machine("119.161.229.251", 25801, "root", "e9497a16")
    , Machine("103.244.76.121", 25801, "root", "e9497a16")
    , Machine("119.161.229.251", 20161, "root", "cd576916")
    , Machine("103.244.76.121", 20161, "root", "cd576916")
    , Machine("183.131.135.213", 20711, "root", "ac5fd0b2")
    , Machine("183.131.135.220", 21011, "root", "a5d1bb7b")
    , Machine("183.131.135.221", 20731, "root", "33a7b1e2")
    , Machine("183.131.135.221", 20741, "root", "09da39f7")
    , Machine("183.131.135.221", 20781, "root", "52121441")
    , Machine("183.131.135.220", 21721, "root", "2dad6540")
    , Machine("183.131.135.221", 20811, "root", "5ec525b9")
    , Machine("183.131.135.221", 20821, "root", "35811706")
    , Machine("122.228.235.46", 20481, "root", "7185803b")
    , Machine("122.228.235.46", 20571, "root", "8a2b8451")
    , Machine("122.228.235.46", 21031, "root", "25fd1bcb")
    , Machine("119.161.229.251", 23471, "Administrator", "120f17ca")
    , Machine("183.131.135.221", 20851, "Administrator", "0b35301b")
    , Machine("119.161.229.250", 27751, "root", "2e65cfd8")
    , Machine("119.161.229.251", 23731, "Administrator", "05dc0fa6")
    , Machine("119.161.229.251", 21691, "Administrator", "0d288c36")
    , Machine("183.131.135.216", 21651, "root", "57997822")
    , Machine("183.131.135.221", 20831, "root", "74fe933d")
    , Machine("119.161.229.250", 27761, "root", "2685e562")
    , Machine("119.161.229.251", 24511, "Administrator", "262461a1")
    , Machine("183.131.135.213", 21281, "root", "11201deb")
    , Machine("122.228.235.47", 20361, "root", "a99c7807")
    , Machine("122.228.235.47", 21631, "root", "d59409d8")
    , Machine("119.161.229.251", 25801, "root", "e9497a16")
    , Machine("119.161.229.251", 20161, "root", "cd576916")
    , Machine("183.131.135.213", 20711, "root", "ac5fd0b2")
    , Machine("119.161.229.251", 21571, "root", "cad76e1d")
    , Machine("119.161.229.251", 21581, "root", "373a9687")
    , Machine("122.228.235.49", 20831, "root", "b8907931")
    , Machine("122.228.235.49", 21041, "root", "b8907931")
    , Machine("122.228.235.49", 21061, "root", "b8907931")
    , Machine("122.228.235.49", 21071, "root", "b8907931")
    , Machine("122.228.235.49", 21091, "root", "b8907931")
    , Machine("122.228.235.49", 21111, "root", "b8907931")
    , Machine("122.228.235.49", 21121, "root", "b8907931")
    , Machine("122.228.235.49", 21151, "root", "b8907931")
    , Machine("122.228.235.49", 21161, "root", "b8907931")
    , Machine("122.228.235.49", 21191, "root", "b8907931")
    , Machine("183.131.135.221", 22051, "root", "84267b49")
    , Machine("183.131.135.221", 22131, "root", "84267b49")
    , Machine("183.131.135.221", 22191, "root", "84267b49")
    , Machine("183.131.135.221", 22421, "root", "84267b49")
]

testSlaveMachine = [
    Machine("122.228.235.49", 21941, "root", "5c6213f1")
    , Machine("183.131.135.216", 21651, "root", "57997822")
]
testMasterMachine = [
    Machine("115.28.25.240", 22, "root", "YWNiMDJ1NjBjds1"),
    Machine("115.29.111.113", 22, "root", "MJc2s7uyfC6t5L5V")
]

prodMasterMachine = [
    # 121.42.55.202 	  root	 MJc2s7uyfC6t5L5V 	生产	redis	22	2
    Machine("115.28.30.163", 22, "root", "MJc2s7uyfC6t5L5V")  # proxy-pool-prod-master-1
    , Machine("139.129.37.227", 22, "root", "MJc2s7uyfC6t5L5V")  # proxy-pool-prod-master-2
    # , Machine("115.28.158.23", 22, "root", "MJc2s7uyfC6t5L5V")    #proxy-pool-prod-master-3
    # , Machine("121.42.150.72", 22, "root", "MJc2s7uyfC6t5L5V")    #proxy-pool-prod-master-4
]

prodSlaveMachine = [
    Machine("119.161.229.251", 20161, "root", "cd576916")  # 1

    , Machine("119.161.229.250", 27751, "root", "2e65cfd8")  # proxy-pool-prod-slave-2

    , Machine("119.161.229.250", 27761, "root", "2685e562")  # proxy-pool-prod-slave-3
    , Machine("183.131.135.221", 22051, "root", "84267b49")  # proxy-pool-prod-slave-4
    , Machine("183.131.135.221", 22421, "root", "84267b49")  # proxy-pool-prod-slave-5
    , Machine("183.131.135.221", 22131, "root", "84267b49")  # proxy-pool-prod-slave-6
    , Machine("183.131.135.221", 22191, "root", "84267b49")  # proxy-pool-prod-slave-7

    , Machine("122.228.235.49", 20831, "root", "b8907931")  # proxy-pool-prod-slave-8
    , Machine("122.228.235.49", 21041, "root", "b8907931")  # proxy-pool-prod-slave-9
    , Machine("122.228.235.49", 21061, "root", "b8907931")  # proxy-pool-prod-slave-10

    , Machine("122.228.235.49", 21071, "root", "b8907931")  # proxy-pool-prod-slave-11
    , Machine("122.228.235.49", 21091, "root", "b8907931")  # proxy-pool-prod-slave-12
    , Machine("122.228.235.49", 21111, "root", "b8907931")  # proxy-pool-prod-slave-13
    , Machine("122.228.235.49", 21121, "root", "b8907931")  # proxy-pool-prod-slave-14


    # , Machine("183.131.135.216", 22911, "root", "a6e6c2ae")  # proxy-pool-prod-slave-15
    # # , Machine("122.228.235.49", 21151, "root", "b8907931")
    # # , Machine("122.228.235.49", 21161, "root", "b8907931")
    # # , Machine("122.228.235.49", 21191, "root", "b8907931")

]
