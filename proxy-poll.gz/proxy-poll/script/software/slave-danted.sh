rm -f /etc/danted.conf
touch /etc/danted.conf
outFile='/etc/danted.conf'

echo '# set paste'  >>${outFile}

echo 'internal: eth1 port = 8989'  >>${outFile}
echo 'external: eth1'  >>${outFile}
echo 'method: username none'  >>${outFile}
echo 'user.privileged: proxy'  >>${outFile}
echo 'user.notprivileged: nobody'  >>${outFile}
echo 'user.libwrap: nobody'  >>${outFile}
echo 'logoutput: /var/log/danted.log'  >>${outFile}


#允许所有的客户端连接
echo 'client pass {'  >>${outFile}
echo '        from: 0.0.0.0/0 to:0.0.0.0/0'  >>${outFile}
echo '        log: connect disconnect'  >>${outFile}
echo '}'  >>${outFile}
echo 'client pass {'  >>${outFile}
echo '        from: 182.50.124.94/0 to:0.0.0.0/0'  >>${outFile}
echo '        log: connect disconnect'  >>${outFile}
echo '}'  >>${outFile}

#允许所有UDP代理 和 DNS解析.
echo 'pass {'  >>${outFile}
echo '       from: 0.0.0.0/0 to: 0.0.0.0/0'  >>${outFile}
echo '       command: bindreply udpreply'  >>${outFile}
echo '       log: connect error'  >>${outFile}
echo '}'  >>${outFile}

echo 'pass {'  >>${outFile}
echo '	from: 0.0.0.0/0 to: 0.0.0.0/0'  >>${outFile}
echo '	command: connect udpassociate'  >>${outFile}
echo '	log: connect disconnect'  >>${outFile}
echo '}'  >>${outFile}
echo 'block {'  >>${outFile}
echo '	from: 0.0.0.0/0 to: 0.0.0.0/0'  >>${outFile}
echo '	log: connect error'  >>${outFile}
echo '}'  >>${outFile}