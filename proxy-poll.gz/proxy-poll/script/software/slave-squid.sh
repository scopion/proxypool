#!/usr/bin/env bash
#wget 'http://download.oracle.com/otn-pub/java/jdk/8u77-b03/jdk-8u77-linux-x64.rpm?AuthParam=1460819747_fa6a2ae41d930b280f6db20ee0d728dc' -O jdk.rpm
#
##rpm -ivh jdk.rpm
#yum localinstall jdk.rpm

rm -f /etc/squid/squid.conf
touch /etc/squid/squid.conf
squidConfigFile='/etc/squid/squid.conf'

###------squid
echo 'http_access allow all' >>${squidConfigFile}
echo 'http_port 8888' >>${squidConfigFile}

# 额外提供给squid使用的内存，squid的内存总占用为 X * 10+15+“cache_mem”，其中X为squid的cache占用的容量（以GB为单位
# 比如下面的cache大小是100M，即0.1GB，则内存总占用为0.1*10+15+64=80M，推荐大小为物理内存的1/3-1/2或更多。
echo 'cache_mem 0 MB' >>${squidConfigFile}

#设置squid磁盘缓存最大文件，超过4M的文件不保存到硬盘
echo 'maximum_object_size 4 MB' >>${squidConfigFile}

#设置squid磁盘缓存最小文件
echo 'minimum_object_size 0 KB '>>${squidConfigFile}

#定义squid的cache存放路径 、cache目录容量（单位M）、一级缓存目录数量、二级缓存目录数量
echo 'cache_dir ufs /var/spool/squid 100 16 256 read-only' >>${squidConfigFile}

#access_log /var/log/squid/access.log //log文件存放路径和日志格式
#cache_log /var/log/squid/cache.log 　　#//设置缓存日志

#//管理员邮箱
echo 'cache_mgr 117815156@qq.com ' >>${squidConfigFile}

#auth_param basic program /usr/lib/squid3/basic_ncsa_auth /etc/squid3/squid_passwd
#auth_param basic realm Welcome to my system
#acl auth_user proxy_auth REQUIRED
#http_access allow auth_user

###--------limit ----------
echo 'ulimit -SHn 65535' >>/etc/rc.local
echo 'ulimit -SHn 65535' >>/etc/profile

limitConfigFile='/etc/security/limits.conf'
echo  'root soft nofile 65535' >> ${limitConfigFile}
echo  'root hard nofile 65535' >> ${limitConfigFile}
echo  '* soft nofile 65535'    >> ${limitConfigFile}
echo  '* hard nofile 65535'    >> ${limitConfigFile}
echo  'session    required /lib64/security/pam_limits.so' >> /etc/pam.d/login


### ---------sysctl
sysCtlConfigFile='/etc/sysctl.conf'
#允许的最多timewait数量
echo 'net.ipv4.tcp_max_tw_buckets = 1024' >>${sysCtlConfigFile}
#允许端口
echo 'net.ipv4.ip_local_port_range = 1024    65535' >>${sysCtlConfigFile}

modprobe bridge
lsmod|grep bridge
#让配置立即生效
sysctl -p



##重新登录
service squid restart

###squid info

##取得squid运行状态信息：
#squidclient -p 8888 -h localhost mgr:info
##取得squid内存使用情况：
#squidclient -p 8888 -h localhost mgr:mem
##取得squid已经缓存的列表：
#squidclient -p 8888 -h localhost mgr:objects
##取得squid的磁盘使用情况：
#squidclient -p 8888 -h localhost mgr:diskd

#java_home=`which java`
#
#alternatives --install /usr/bin/java java /usr/java/${java_home}/jre/bin/java 20000
#alternatives --install /usr/bin/jar jar /usr/java/${java_home}/bin/jar 20000
#alternatives --install /usr/bin/javac javac /usr/java/${java_home}/bin/javac 20000
#alternatives --install /usr/bin/javaws javaws /usr/java/${java_home}/jre/bin/javaws 20000
#alternatives --set java /usr/java/${java_home}/jre/bin/java
#alternatives --set jar /usr/java/${java_home}/bin/jar
#alternatives --set javac /usr/java/${java_home}/bin/javac
#alternatives --set javaws /usr/java/${java_home}/jre/bin/javaws
# df -hl
