from SSH import sshTo, sftpTo
from CacheLib import slaveLibName, masterLibName, slaveLibPath, masterLibPath
import os


def only_out_err(p):
    i, o, e = p
    a = e.readlines()
    if len(a) > 0:
        for i in a: print i


def do(ssh, fileName, cmds):
    ssh.exec_command("rm -f " + fileName)
    only_out_err(ssh.exec_command("\n".join(cmds)))


class Squid:
    def __init__(self):
        file = open(r"software/slave-squid.sh", 'r')
        self.slave = file.readlines()

    def initSlave(self, machine):
        ssh = sshTo(machine)
        do(ssh, "slave-squid.sh", self.slave)
        ssh.close()
        print ("init squid slave " + machine.id())


class Cmd:
    def __init__(self):
        self.slave = []
        self.master = []

    def initSlave(self, machine):
        ssh = sshTo(machine)
        do(ssh=ssh, fileName="test-slave.sh", cmds=self.slave)
        ssh.exec_command("mkdir /data/config")
        ssh.exec_command("mkdir /data/proxy-pool")
        ssh.exec_command("mkdir /data/proxy-pool/public-lib")
        ssh.exec_command("echo \"" + machine.id() + " \" >/data/proxy-pool/slave_name")
        ssh.exec_command("echo \"" + machine.id() + " \" >/data/config/slave_name")
        ssh.close()
        print ("init cmd slave " + machine.id())

    def initMaster(self, machine):
        ssh = sshTo(machine)
        do(ssh=ssh, fileName="test-master.sh", cmds=self.master)
        ssh.exec_command("mkdir /data/config")
        ssh.exec_command("mkdir /data/proxy-pool")
        ssh.exec_command("mkdir /data/proxy-pool/public-lib")
        ssh.exec_command("echo '" + machine.host + "' >>/data/config/default_ip")
        ssh.exec_command("echo '" + machine.host + "' >>/data/proxy-pool/default_ip")
        ssh.close()
        print ("init cmd master " + machine.id())


class CacheLib:
    def __init__(self):
        self.master = []
        self.slave = []

    def initSlave(self, machine):
        t, sftp = sftpTo(machine)
        for (localPath, removePath) in self.slave:
            sftp.put(localPath, removePath)
        t.close()
        sftp.close()
        print ("init lib slave " + machine.id())

    def initMaster(self, machine):
        t, sftp = sftpTo(machine)
        for (localPath, removePath) in self.master:
            sftp.put(localPath, removePath)
        t.close()
        sftp.close()
        print ("init lib master " + machine.id())


class Proper:
    def __init__(self):
        self.cmd = Cmd()
        self.lib = CacheLib()
        self.squid = Squid()


class InitMachine:
    def __init__(self):
        self.prod = Proper()
        self.test = Proper()

        self.prod.cmd.master = open(r"sh/prod-master.sh", "r").readlines()
        self.prod.cmd.slave = open(r"sh/prod-slave.sh", "r").readlines()

        self.test.cmd.master = open(r"sh/test-master.sh", "r").readlines()
        self.test.cmd.slave = open(r"sh/test-slave.sh", "r").readlines()

        self.prod.lib.master = masterLibPath
        self.prod.lib.slave = slaveLibPath

        self.test.lib.master = masterLibPath
        self.test.lib.slave = slaveLibPath
