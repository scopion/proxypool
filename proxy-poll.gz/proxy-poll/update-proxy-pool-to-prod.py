import script
from script.Machine import testSlaveMachine, slaveList, testMasterMachine, prodMasterMachine, prodSlaveMachine
from script.SSH import sshTo, sftpTo
import paramiko
import thread
import thread
from multiprocessing import Pool
from multiprocessing.dummy import Pool as ThreadPool

masterPool = ThreadPool(len(prodMasterMachine) + 1)
slavePool = ThreadPool(len(prodSlaveMachine) + 1)

proxyPoolPath = "/data/proxy-pool/"
proxyPoolFile = "proxy-pool.zip"


def uploadFileToMaster(machine):
    t, sftp = sftpTo(machine)
    proxyPoolFile = "proxy-pool.zip"
    print ("update proxy-pool.zip to master ip:" + machine.id())
    sftp.put(localpath=r"proxy-pool-master/proxy-pool.zip", remotepath=proxyPoolPath + proxyPoolFile)
    print ("update proxy-pool.zip to master successful ip:" + machine.id())


def uploadFileToSlave(machine):
    t, sftp = sftpTo(machine)
    proxyPoolFile = "proxy-pool.zip"
    print ("update proxy-pool.zip to slave ip:" + machine.id())
    sftp.put(localpath=r"proxy-pool-slave/proxy-pool.zip", remotepath=proxyPoolPath + proxyPoolFile)
    print ("update proxy-pool.zip to slave successful ip:" + machine.id())


# needUploadToMaster = raw_input("are you want to upload to prod master [y|n]:")
# if needUploadToMaster == "y":
# masterPool.map(uploadFileToMaster, prodMasterMachine)

# needUploadToSlave = raw_input("are you want ot upload to prod slave  [y|n]:")
# if needUploadToSlave == "y":
for a in prodSlaveMachine : uploadFileToSlave(a)
# slavePool.map(uploadFileToSlave, prodSlaveMachine)
