package articleDegree

/**
  * Created by yujieshui on 2016/4/21.
  */
case class SayHello(msg: String) extends Serializable