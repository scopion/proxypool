/**
  * Created by yujieshui on 2016/4/14.
  */
package object articleDegree {
  // todo change to case class
  val RestartStr   = 3

}
