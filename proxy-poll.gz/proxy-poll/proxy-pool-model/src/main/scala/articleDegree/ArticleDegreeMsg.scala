package articleDegree

/**
  * Created by yujieshui on 2016/4/14.
  */

trait ArticleDegreeMsg extends Serializable

case class AdslIp(slaveName: String, ip: String) extends ArticleDegreeMsg


case class UseProxy(user: UserEnum.Value) extends ArticleDegreeMsg

case class RegisteredSlave(slaveActorPath: String,
                           name: String,
                           ip: String,
                           port: String,
                           password: String,
                           slaveVersion: String,
                           startTime: Long) extends ArticleDegreeMsg

case class RegisteredRespond(masterName: String,
                             result: Boolean,
                             causeBy: Option[String],
                             restartTime: Long) extends ArticleDegreeMsg

case class IpInvalid(ip: String, user: UserEnum.Value) extends ArticleDegreeMsg

case class Restart(slaveName: String) extends ArticleDegreeMsg

case class PingMasterToSlave(masterName: String) extends ArticleDegreeMsg

case class PingSlaveToMaster(slaveName: String) extends ArticleDegreeMsg

case class HasRecord(slaveName: String) extends ArticleDegreeMsg

case class FindAnotherMaster() extends ArticleDegreeMsg


case class SlaveRestart() extends ArticleDegreeMsg

case class GlobalAllowIp(ipList: List[String]) extends ArticleDegreeMsg

case class TemporaryAllowIp(ipList: List[String]) extends ArticleDegreeMsg