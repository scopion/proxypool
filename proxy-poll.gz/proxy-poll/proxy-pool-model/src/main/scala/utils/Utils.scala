package utils

import scala.util.{Success, Try}

import java.io.{InputStreamReader, BufferedReader}
import java.lang.management.ManagementFactory
import java.net.{NetworkInterface, InetAddress}
import scala.collection.JavaConverters._
import scala.collection.JavaConversions._

/**
  * Created by yujieshui on 2016/4/1.
  */
object Utils {
  @deprecated
  def getIp(): String = {
    Try {
      val r = "addr:([0-9|.]+) ".r

      val list = ifConfig()

      val ip =
        r.findAllIn(list.mkString("\n")).toList.map(_.split(":").last)
      ip.last.trim
    }.getOrElse {
      val netAddress = InetAddress.getLocalHost
      netAddress.getHostAddress
    }
  }

  private[this]
  val ipRegx = "addr:([0-9|.]+) ".r

  def get_netAddress_ip() = {
    val netAddress = InetAddress.getLocalHost
    netAddress.getHostAddress
  }

  def get_ppp0_ip(): Option[String] = {
    Try {
      val list = cmd("ifconfig ppp0")
      val ip =
        ipRegx.findAllIn(list.mkString("\n")).toList.map(_.split(":").last)
      ip.last.trim
    }.toOption

  }

  def get_eth1_ip(): Option[String] = {
    Try(
      ipRegx.findAllIn(cmd(s"ifconfig eth1").mkString("\n")).toList.map(_.split(":").last).last.trim
    ).toOption
  }

  def get_eth_ip(): Option[String] = {
    0 to 10 map ("eth" + _.toString) map { name =>
      Try(
        ipRegx.findAllIn(cmd(s"ifconfig $name").mkString("\n")).toList.map(_.split(":").last).last.trim
      )
    } collectFirst {
      case Success(ip) => ip
    }
  }

  def restartAdsl(): Unit = {
    val a = Try {
      cmd("adsl-stop")
      Thread.sleep(1000)
      cmd("adsl-start")
      curlBaidu()
    }
    if (a.isFailure)
      a.failed.get.printStackTrace()
  }

  def curlBaidu(): Boolean = {
    val cmdResult = cmd("curl https://www.baidu.com/").mkString("\n")

    val isFail = cmdResult.contains("Couldn't resolve host") || cmdResult.replaceAll("\n|\r|\t", "").trim.isEmpty
    val isSuccess = !isFail

    if (isSuccess) {
      println("curl baidu success ")
      println(cmdResult)
      true
    }
    else {
      println("curl baidu fail")
      println(cmdResult)
      Thread.sleep(1000)
      curlBaidu()
    }
  }

  def pid(): String = {
    val name = ManagementFactory.getRuntimeMXBean.getName
    val pid = name.split("@").apply(0)
    pid
  }

  def mac(): String = {
    Try {
      LOCALMAC.mac()
    }.getOrElse {
      val list = ifConfig()
      val r = "HWaddr .*".r
      r.findAllIn(list.mkString("\n")).toList.head.replace("HWaddr", "").trim
    }
  }

  def ifConfig(): List[String] = cmd("ifconfig -a")

  def cmd(s: String) = {
    new BufferedReader(new InputStreamReader(
      Runtime.getRuntime.exec(s).getInputStream
    )).lines().iterator().toList
  }

  def restartSocket(): Unit = {}

  def pattenConfigResource(string: String): Option[String] = {
    val r = "-Dconfig.resource=(.*)".r
    string match {
      case r(configFile) => Some(configFile)
      case _             => None
    }
  }
}
