package utils;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;

/**
 * Created by yujieshui on 2016/4/7.
 */
public class LOCALMAC {

  private static String getMACAddress(InetAddress ia) throws Exception {
    byte[] mac = NetworkInterface.getByInetAddress(ia).getHardwareAddress();

    StringBuffer sb = new StringBuffer();

    for (int i = 0; i < mac.length; i++) {
      if (i != 0) {
        sb.append("-");
      }
      String s = Integer.toHexString(mac[i] & 0xFF);
      sb.append(s.length() == 1 ? 0 + s : s);
    }

    return sb.toString().toUpperCase();
  }

  public static String mac() throws Exception {
    return getMACAddress(InetAddress.getLocalHost());
  }
}
