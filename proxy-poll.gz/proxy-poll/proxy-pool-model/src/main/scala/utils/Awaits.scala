package utils

import scala.concurrent.Future

/**
  * Created by yujieshui on 2016/4/8.
  */
object Awaits {

  implicit class aw[T](val future: Future[T]) {
    def await = scala.concurrent.Await.result(future, scala.concurrent.duration.Duration.Inf)
  }

}
